package ConnessionDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnessioneDatabase {
    private static ConnessioneDatabase instance;
    private Connection connection;
    private final String url = "jdbc:postgresql://localhost:5432/biblioteca_digitale";
    private final String nome = "postgres";
    private final String password = "Rosanna2";
    private ConnessioneDatabase() throws SQLException {

        // Crea la connessione al database
        connection = DriverManager.getConnection(url, nome, password);
    }

    public static ConnessioneDatabase getInstance() throws SQLException {
        // Se la connessione non esiste o è chiusa, ne creo una nuova
        if (instance == null || instance.getConnection().isClosed()) {
            instance = new ConnessioneDatabase();
        }
        // Restituisco il riferimento a quella esistente
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }
}
