package Controller;

import DAO.*;

import model.*;
import implementazionePostgresDAO.*;

import javax.swing.*;
import java.util.*;

/**
 * Il tipo Controller.
 */
public class Controller {

    /**
     * Visualizza i canali di distribuzione che dispongono per intero di una serie preferita dell'utente
     *
     * @param matricola La matricola dell'utente
     * @return Il nome dei canali e il nome della serie disponibile presso quel canale
     */
    public List<List<String>> visualizzaCanaliDistribuzione (int matricola) {

        CanaleDistribuzioneDAO canaleDistribuzioneDAO = new CanaleDistribuzioneDAOImpl();

        return  canaleDistribuzioneDAO.trovaCanaliDistribuzioneSerie(matricola);


    }

    /**
     * Visualizza il titolo dei libri presenti nel database.
     *
     * @return la lista dei titoli dei libri
     */
    public List<String> visualizzaLibri() {
        List<String> risultati = new ArrayList<>();


        for( String libro : new LibroDAOImpl().visualizzaLibri()) {
            risultati.add(libro);
        }

        return risultati;
    }


    /**
     * Visualizza il titolo delle pubblicazioni presenti nel database.
     *
     * @return la lista dei titoli delle pubblicazioni
     */
    public List<String> visualizzaPubblicazioni () {

        return new PubblicazioneDAOImpl().visualizzaPubblicazioni();

    }

    /**
     * Verifica l'esistenza di un utente.
     *
     * @param matricola la matricola dell'utente
     * @return vero se l'utente esiste, falso altrimenti
     */
    public boolean verificaEsistenzaUtente(int matricola) {
        return new UtenteDAOImpl().utenteEsiste(matricola);
    }

    /**
     * Verifica esistenza se esiste un utente che utilizza quell'username.
     *
     * @param username l'username da ricercare
     * @return vero se esiste un utente con tale username, falso altrimenti
     */
    public boolean verificaEsistenzaUsername ( String username ) {
        return new UtenteDAOImpl().usernameEsiste(username);
    }

    /**
     * Effettua la ricerca dell'utente che desidera effettuare il login nel database
     *
     * @param matricola la matricola dell'utente
     * @param password  la password dell'utente
     * @return vero se il login è andato a buon fine, falso altrimenti
     */
    public boolean effettuaLogin (int matricola, String password){
        return new UtenteDAOImpl().effettuaLogin(matricola, password);
    }

    /**
     * Effettua la registrazione di un nuovo utente.
     *
     * @param matricola la matricola
     * @param password  la password
     * @param nome      il nome
     * @param cognome   il cognome
     * @param username  l' username
     * @return vero se la registrazione è andata a buon fine, falso altrimenti
     */
    public boolean effettuaRegistrazione (int matricola, String password, String nome, String cognome, String username) {
        return new UtenteDAOImpl().effettuaRegistrazione(matricola, password, nome, cognome, username);
    }

    /**
     * Aggiunge una serie alla lista dei preferiti dell'utente dato in input.
     *
     * @param matricola la matricola
     * @param serie     la serie
     * @return vero se l'inserimento è andato a buon fine, falso altrimenti
     */
    public boolean aggiungiSeriePreferita (int matricola, String serie) {

        Serie seriePreferita =  new SerieDAOImpl().cercaSerie("nome", serie).get(0);

        PreferitiDAO p = new PreferitiDAOImpl();
        if(p.serieGiaPreferita(matricola, seriePreferita.getCodSerie())) return false;

        return p.aggiungiSeriePreferita(matricola,seriePreferita.getCodSerie());
    }

    /**
     * Ricerca tutte le serie presenti nel database
     *
     * @return la lista dei nomi di tutte le serie
     */
    public List<String> elencoSerie() {
        return new SerieDAOImpl().getElencoSerie();
    }


    /**
     * Ricerca tutte le serie presenti nel database
     *
     * @return la lista dei codici delle serie
     */
    public List<Integer> elencoSerieCod() {
        return new SerieDAOImpl().getElencoSerieCod();
    }

    /**
     * Ricerca tutte le riviste presenti nel database
     *
     * @return l'elenco dei DOI di tutte le riviste
     */
    public List<String> getElencoRiviste() {
       return new RivistaDAOImpl().getElencoRiviste();

    }

    /**
     * Ricerca tutte le conferenze presenti nel database
     *
     * @return L'elenco dei codici di tutte le conferenze
     */
    public List<Integer> getElencoConferenze() {
        return new ConferenzaDAOImpl().getElencoConferenze();
    }

    /**
     * Effettua l'inserimento di un libro all'interno di un database.
     *
     * @param ISBN              l' isbn
     * @param titolo            il titolo
     * @param tipo              il tipo
     * @param editore           l' editore
     * @param salaPresentazione la sala presentazione
     * @param dataUscita        la data uscita
     * @param annoPubblicazione l' anno pubblicazione
     * @param modaliFruizione   la\le modalita di fruizione
     * @param serie             l'eventuale serie a cui appartiene il libro
     * @param autore            l' autore o gli autori
     * @return vero se l'inserimento è andato a buon fine, falso altrimenti.
     */
    public boolean aggiungiLibro(String ISBN, String titolo, String tipo, String editore, String salaPresentazione, Date dataUscita, int annoPubblicazione, Set<String> modaliFruizione, int serie, Set<String> autore) {
        Libro l = null;

        if (serie == -1) {
            l = new Libro(ISBN, titolo, editore,  dataUscita, salaPresentazione, tipo, annoPubblicazione, autore);

        } else {
            Serie s = new SerieDAOImpl().cercaSerieCod(serie);
            l = new Libro(ISBN, titolo, editore, dataUscita, salaPresentazione, tipo, annoPubblicazione, autore, s);
        }

        l.setModalitaFruizione(modaliFruizione);
        LibroDAO lib = new LibroDAOImpl();
        return lib.inserisciLibro(l);
    }

    /**
     * Effettua l'inserimento di una pubblicazione all'interno del database
     *
     * @param ISBN              l' isbn
     * @param titolo            il titolo
     * @param editore           l' editore
     * @param annoPubb          l' anno pubblicazione
     * @param conferenza        la conferenza
     * @param rivista           la rivista
     * @param modalitaFruizione la\le modalita fruizione
     * @param autori            l'autore o gli autori
     * @return vero se l'inserimento è andato a buon fine falso altrimenti
     */
    public boolean aggiungiPubblicazione (String ISBN, String titolo, String editore, String annoPubb, String conferenza, String rivista, Set<String> modalitaFruizione, Set<String> autori) {
        Pubblicazione p = null;

        if(rivista == null) {
            Conferenza c = new ConferenzaDAOImpl().recuperaConferenzaDaDatabase(Integer.parseInt(conferenza));
            p = new Pubblicazione(ISBN, titolo, editore, Integer.parseInt(annoPubb), autori, c);
        } else {
            Rivista r = new RivistaDAOImpl().recuperaRivistaDaDatabase(rivista);
            p = new Pubblicazione(ISBN, titolo, editore, Integer.parseInt(annoPubb), autori, r);
        }

        p.setModalitaFruizione(modalitaFruizione);

        return new PubblicazioneDAOImpl().inserisciPubblicazione(p);
    }


    /**
     * Ricerca tutti i canali di distribuzione presenti nel database
     *
     * @return L'elenco dei nomi dei canali di distribuzione
     */
    public List<String> visualizzaCanali () {
        return new CanaleDistribuzioneDAOImpl().visualizzaCanali();

    }

    /**
     * Aggiunge la disponibilità di un libro presso un canale in una specifica modalita di fruizione.
     *
     * @param libro    il libro di cui inserire la disponibilità
     * @param canale   il canale presso cui sarà disponbile il libro
     * @param modalita la modalita di fruizione
     * @return vero se l' inserimento è andato a buon fine, falso altrimenti
     */
    public boolean aggiungiDisponibilitaLibro (String libro, String canale, String modalita) {
        if( libro != null && canale != null) {
            LibroDAO lib = new LibroDAOImpl();
            Libro l = lib.cercaLibro("titolo", libro).get(0);

            CanaleDistribuzione c = new CanaleDistribuzioneDAOImpl().trovaCanaleDistribuzione(canale);

            return lib.aggiungiDisponibilita(l.getISBN(), c.getCodCanale(), modalita);

        }
        return false;
    }

    /**
     * Aggiunge la disponibilità di una pubblicazione presso un canale in una specifica modalita di fruizione.
     *
     * @param pubblicazione la pubblicazione di cui inserire la disponibilità
     * @param canale        il canale presso cui sarà disponibile la pubblicazione
     * @param modalita      la modalita di fruizione
     * @return vero se l'inserimento è andato a buon fine falso altrimenti
     */
    public boolean aggiungiDisponibilitaPubblicazione (String pubblicazione, String canale, String modalita) {
        if( pubblicazione != null  && canale != null) {
            PubblicazioneDAO pubb = new PubblicazioneDAOImpl();
            Pubblicazione p = pubb.cercaPubblicazioni("titolo", pubblicazione).get(0);

            CanaleDistribuzione c = new CanaleDistribuzioneDAOImpl().trovaCanaleDistribuzione(canale);

            return  pubb.aggiungiDisponibilita(p.getISBN(), c.getCodCanale(), modalita);
        }
        return false;
    }


    /**
     * Ricerca le modalita di fruizione di un libro
     *
     * @param libro  il libro che ci interessa
     * @return le modalita di fruizione del libro
     */
    public Set<String> getModalitaFruizioneLibro(String libro) {

        if (libro != null) {
            LibroDAO lib = new LibroDAOImpl();
            Libro l = lib.cercaLibro("titolo", libro).get(0);
             return l.getModalitaFruizione();
        }

        return null;
    }

    /**
     * Ricerca le modalita di fruizione di una pubblicazione
     *
     * @param pubb la pubblicazione che ci interessa
     * @return le modalita di fruizione
     */
    public Set<String> getModalitaFruizionePubblicazione(String pubb) {
        if (pubb != null) {
            Pubblicazione p = new PubblicazioneDAOImpl().cercaPubblicazioni("titolo", pubb).get(0);
            Set<String> modalita = p.getModalitaFruizione();


            return modalita;
        } else {
            return null;
        }
    }


    /**
     * Ricerca le serie preferite di un utente
     *
     * @param matricola la matricola dell'utente
     * @return l'elenco dei nomi delle serie preferite dell'utente
     */
    public List<String> SeriePreferite(int matricola) {
       return new PreferitiDAOImpl().SeriePreferite(matricola);

    }

    /**
     * Elimina una serie dall'eleno dei preferiti dell'utente.
     *
     * @param matricola la matricola dell'utente
     * @param serie     la serie da eliminare dall'elenco
     * @return vero se l'eliminazione è avvenuta con successo, falso altrimenti
     */
    public boolean eliminaSeriePreferita ( int matricola, String serie) {
        PreferitiDAO p = new PreferitiDAOImpl();
        Serie seriePreferita =new SerieDAOImpl().cercaSerie("nome", serie).get(0);

        return p.eliminaSeriePreferita(matricola,seriePreferita.getCodSerie());
    }

    /**
     * Cerca tutti gli articoli (libri e pubblicazioni) presenti nel database.
     *
     * @param attributo   il campo su cui si vuole filtrare la ricerca
     * @param searchString il valore del campo
     * @return una lista che contiene: la lista di libri e la lista di pubblicazione risultanti
     */
    public List<List<String>> cercaArticoli(String attributo, String searchString) {
        List<Libro> risultatoLibri = new LibroDAOImpl().cercaLibro(attributo, searchString);
        List<Pubblicazione> risultatoPubblicazioni = new PubblicazioneDAOImpl().cercaPubblicazioni(attributo, searchString);
        List<String> listaTitoliLibri = new ArrayList<>();
        List<String> listaTitoliPubblicazioni = new ArrayList<>();

        for (Pubblicazione pubblicazione : risultatoPubblicazioni)
            listaTitoliPubblicazioni.add(pubblicazione.getTitolo());

        for (Libro libro : risultatoLibri) {
            listaTitoliLibri.add(libro.getTitolo());
        }

        List<List<String>> risultati = new ArrayList<>();
        risultati.add(listaTitoliLibri);
        risultati.add(listaTitoliPubblicazioni);

        return risultati;
    }


    /**
     * Cerca un libro\i all'interno del database.
     *
     * @param attributo    il campo su cui si vuole filtrare la ricerca
     * @param searchString il valore del campo
     * @return vero se è stato trovato almeno un libro, falso altrimenti
     */
    public boolean cercaLibro (String attributo, String searchString) {
        List<Libro> risultatoLibri = new LibroDAOImpl().cercaLibro(attributo, searchString);

        return (!risultatoLibri.isEmpty());

    }

    /**
     * Cerca pubblicazione1i all'interno del database
     *
     * @param attributo   il campo su cui si vuole filtrare la ricerca
     * @param searchString tl valore del campo
     * @return ero se è stato trovato almeno una pubblicazione, falso altrimenti
     */
    public boolean cercaPubblicazione (String attributo, String searchString) {
        List<Pubblicazione> risultatoPubblicazioni = new PubblicazioneDAOImpl().cercaPubblicazioni(attributo, searchString);

        return (!risultatoPubblicazioni.isEmpty());

    }

    /**
     * Cerca un caanale di distribuzione mediante il nome.
     *
     * @param nome il nome del canale
     * @return il canale distribuzione
     */



    /**
     * RIcerca i libri appartenenti ad una specifica serie.
     *
     * @param nomeSerie il nome della serie
     * @return i titoli dei libri appartenenti alla serie
     */
    public List<String> getLibriSerie(String nomeSerie) {
        Serie serie = new SerieDAOImpl().cercaSerie("nome", nomeSerie).get(0);
        List<String> risultati = new ArrayList<>();

        if (serie != null) {

            risultati = new LibroDAOImpl().getLibriSerie(serie.getCodSerie());

        }

        return risultati;
    }

    /**
     * Ricerca i libri di una collana.
     *
     * @param nomeCollana il nome della collana
     * @return l'elenco dei titoli dei libri appartenenti alla collana
     */
    public List<String> getLibriCollana ( String nomeCollana) {
        Collana collana = new CollanaDAOImpl().trovaCollana(nomeCollana);
        List<String> risultati = new ArrayList<>();

        if (collana != null) {
             risultati = new LibroDAOImpl().getLibriCollana(collana.getCodcollana());
            }
        else System.out.println("Collana non trovata");


        return risultati;
    }


    /**
     * Ricerca i canali presso i quali è disponbile un libro
     *
     * @param articolo l'articolo
     * @param tipo     il tipo (libro o pubblicazione)
     * @return la lista dei canali presso cui è disponibile l'articolo, e le modalita di fruizione per cui è disponbile
     */
    public Map<String, Set<String>> disponibilita(String articolo, String tipo) {
        CanaleDistribuzioneDAO c = new CanaleDistribuzioneDAOImpl();

        if (tipo.equals("Libro")) {
           return  c.disponibilita(new LibroDAOImpl().cercaLibro("titolo", articolo).get(0));

        } else if (tipo.equals("Pubblicazione")) {
            return c.disponibilita(new PubblicazioneDAOImpl().cercaPubblicazioni("titolo", articolo).get(0));
        }

        return null;

    }


    /**
     * Recupera un libro dal database ricercandolo per il titolo.
     *
     * @param articolo il titolo del libro
     * @return restituisce una stringa contenente tutte le informazioni del libro
     */
    public String visualizzaDettagliLibro(String articolo) {
        Libro libro = new LibroDAOImpl().cercaLibro("titolo", articolo).get(0);

        if (libro.getSerie() != null) {
            return "ISBN: " + libro.getISBN() + "\n"
                    + "Titolo: " + libro.getTitolo() + "\n"
                    + "Editore: " + libro.getEditore() + "\n"
                    + "Data uscita: " + libro.getDataUscita() + "\n"
                    + "Sala presentazione: " + libro.getSala() + "\n"
                    + "Tipo: " + libro.getTipo() + "\n"
                    + "Anno di pubblicazione: " + libro.getAnnoPubblicazione() + "\n"
                    + "Autori: " + libro.getAutori() + "\n"
                    + "Modalità di fruizione: " + libro.getModalitaFruizione() + "\n"
                    + "Serie: " + libro.getSerie().getNome() + "\n";
        }

        return "ISBN: " + libro.getISBN() + "\n"
                + "Titolo: " + libro.getTitolo() + "\n"
                + "Editore: " + libro.getEditore() + "\n"
                + "Data uscita: " + libro.getDataUscita() + "\n"
                + "Sala presentazione: " + libro.getSala() + "\n"
                + "Tipo: " + libro.getTipo() + "\n"
                + "Anno di pubblicazione: " + libro.getAnnoPubblicazione() + "\n"
                + "Autori: " + libro.getAutori() + "\n"
                + "Modalità di fruizione: " + libro.getModalitaFruizione() + "\n";

    }

    /**
     * RIcerca una pubblicazione nel database mediante il titolo
     *
     * @param articolo il titolo della pubblicazione
     * @return la stringa contenente tutti i dettagli di quella pubblicazione
     */
    public String visualizzaDettagliPubblicazione (String articolo) {
        Pubblicazione pubblicazione = new PubblicazioneDAOImpl().cercaPubblicazioni("titolo", articolo).get(0);

        String dettagli  = null;
        if (pubblicazione != null && pubblicazione.getConferenza() == null) {
            dettagli = "ISBN: " + pubblicazione.getISBN() + "\n"
                    + "Titolo: " + pubblicazione.getTitolo() + "\n"
                    + "Editore: " + pubblicazione.getEditore() + "\n"
                    + "Anno di pubblicazione: " + pubblicazione.getAnnoPubblicazione() + "\n"
                    + "Autori: " + pubblicazione.getAutori() + "\n"
                    + "Rivista: " + pubblicazione.getRivista().getNome() + "\n"
                    + "Modalità di fruizione: " + pubblicazione.getModalitaFruizione() + "\n";
        } else {
            dettagli = "ISBN: " + pubblicazione.getISBN() + "\n"
                    + "Titolo: " + pubblicazione.getTitolo() + "\n"
                    + "Editore: " + pubblicazione.getEditore() + "\n"
                    + "Anno di pubblicazione: " + pubblicazione.getAnnoPubblicazione() + "\n"
                    + "Autori: " + pubblicazione.getAutori() + "\n"
                    + "Conferenza: " + pubblicazione.getConferenza().getNome() + "\n"
                    + "Modalità di fruizione: " + pubblicazione.getModalitaFruizione() + "\n" ;
        }
        return dettagli;
    }

    /**
     * Recupera tutte le collane dal database.
     *
     * @return un hashmap contenente nome della collana, editore della collana
     */
    public  List<String>  getCollane () {
        List<String> risultati = new ArrayList<>();
        CollanaDAO collanaDAO =  new CollanaDAOImpl();


        for ( List<String> lista : collanaDAO.getCollane()) {

            String s = new String(lista.get(0) + " - " + lista.get(1));
            risultati.add(s);

        }

        return risultati;
    }


    /**
     * Elimina un libro dal database
     *
     * @param titolo il titolo del libro
     * @return restituisce true se l'eliminazione è andata a buon fine, false altrimenti
     */
    public boolean eliminaLibro (String titolo) {

        LibroDAO l = new LibroDAOImpl();
        return l.eliminaLibro(titolo);
    }

    /**
     * Elimina una pubblicazione dal database.
     *
     * @param titolo il titolo della pubblicazione
     * @return restituisce true se l'eliminazione è andata a buon fine, false altrimenti
     */
    public boolean eliminaPubblicazione (String titolo) {
        return new PubblicazioneDAOImpl().eliminaPubblicazione(titolo);
    }

    /**
     * Verifica se una pubblicazione è gia disponibile o meno, presso uno specifico canale di distribuzione in una specifica modalita di fruizione
     *
     * @param pubb     la pubblicazione
     * @param canale   il canale di distribuzione
     * @param modalita la modalita di fruizione
     * @return restituisce vero se la pubblicazione eà già disponibile presso quel canale di distribuzione in quella specifica modalità, falso altrimenti
     */
    public boolean verificaDisponibilitaPubblicazione(String pubb, String canale, String modalita) {
        PubblicazioneDAO pubblicazioneDAO = new PubblicazioneDAOImpl();
        Pubblicazione p = pubblicazioneDAO.cercaPubblicazioni("titolo", pubb).get(0);

        CanaleDistribuzioneDAO can = new CanaleDistribuzioneDAOImpl();

        Map<String, Set<String>> disp = can.disponibilita(p); // I canali dove è disponibile quella pubblicazione

        Set<String> modalitaFruizione = disp.get(canale);

        return modalitaFruizione != null && modalitaFruizione.contains(modalita);
    }


    /**
     * Verifica se un libro è gia disponibile o meno, presso uno specifico canale di distribuzione in una specifica modalita di fruizione
     *
     * @param libro    il libro
     * @param canale   il canale
     * @param modalita la modalita di fruizione
     * @return restituisce vero se il libro  già disponibile presso quel canale di distribuzione in quella specifica modalità, falso altrimenti
     */
    public boolean verificaDisponibilitaLibro(String libro, String canale, String modalita) {
        LibroDAO lib = new LibroDAOImpl();
        Libro l = lib.cercaLibro("titolo", libro).get(0);

        CanaleDistribuzioneDAO can = new CanaleDistribuzioneDAOImpl();

        Map<String, Set<String>> disp = can.disponibilita(l); // Restituisce le disponibilità di quel libro presso i vari canali

        Set<String> modalitaFruizione = disp.get(canale);

        return modalitaFruizione != null && modalitaFruizione.contains(modalita);
    }

}







