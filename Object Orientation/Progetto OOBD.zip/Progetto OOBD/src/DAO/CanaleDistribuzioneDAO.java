package DAO;

import model.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * L'interfaccua Canale distribuzione DAO.
 */
public interface CanaleDistribuzioneDAO {

    /**
     * Trova i canali distribuzione che dispongono per intero di almeno una serie preferita dell'utente.
     *
     * @param utente l'utente di interesse
     * @return una lista di liste di stringhe (lista di (nome Canale, nome Serie di cui dispone))
     */
    List<List<String>> trovaCanaliDistribuzioneSerie(int utente);

    /**
     * Visualizza tutti i canali di distrobuzione.
     *
     * @return la lista dei nomi dei canali
     */
    List<String> visualizzaCanali ();

    /**
     * Trova canale distribuzione mediante il nome.
     *
     * @param nome il nome del canale
     * @return l'intero oggetto canale distribuzione
     */
    CanaleDistribuzione trovaCanaleDistribuzione(String nome);

    /**
     * Restituisce tutti i canali che dispongono di uno specifico libro.
     *
     * @param libro il libro per cui effettuare l'operazione
     * @return una hashmap (nome Canale, modalita di fruizione per cui il libro e' disponbile)
     */
    Map<String, Set<String>> disponibilita  (Libro libro);

    /**
     * Restituisce tutti i canali che dispongono di una specifica pubblicazione.
     *
     * @param pubblicazione la pubblicazione per cui effettuare l'operazione
     * @return na hashmap (nome Canale, modalita di fruizione per cui la pubblicazione e' disponbile)
     */
    Map<String, Set<String>> disponibilita (Pubblicazione pubblicazione);

}
