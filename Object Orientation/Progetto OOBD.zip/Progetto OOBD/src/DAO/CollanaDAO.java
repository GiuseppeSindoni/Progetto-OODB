package DAO;

import model.Collana;

import java.util.List;

/**
 * L'interfaccia Collana DAO.
 */
public interface CollanaDAO {

    /**
     * Restutyisce tutte le collane.
     *
     * @return una lista di liste di stringhe (nome Collana, editore della collana)
     */
    List<List<String >> getCollane ();

    /**
     * Trova una collana mediante il nome.
     *
     * @param nome il nome della collana
     * @return l'intera collana
     */
    Collana trovaCollana (String nome);
}
