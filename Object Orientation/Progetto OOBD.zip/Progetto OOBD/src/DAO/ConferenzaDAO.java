package DAO;

import model.Conferenza;

/**
 * The interface Conferenza dao.
 */
public interface ConferenzaDAO {


    /**
     * Recupera una conferenza dal database mediante il codice identificativo.
     *
     * @param idConferenza til codice della conferenza
     * @return la conferenza ricercata
     */
    Conferenza recuperaConferenzaDaDatabase(int idConferenza);
}
