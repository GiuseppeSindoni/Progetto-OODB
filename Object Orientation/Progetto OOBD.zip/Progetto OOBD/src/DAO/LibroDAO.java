// Package DAO
package DAO;

import model.*;


import java.util.List;
import java.util.Map;

/**
 * L'interfaccia Libro DAO.
 */
public interface LibroDAO {
    /**
     * Effettua una ricerca dei libri, filtrando il valore secondo il valore di uno specifico campo.
     *
     * @param campo il campo
     * @param searchString il valore del campo
     * @return la lista di libri risultanti
     */
    List<Libro> cercaLibro(String campo, String searchString);

    /**
     * Ottieni i libri appartenenti d una serie.
     *
     * @param serie la serie in questione
     * @return i libri appartenenti alla serie data in input
     */
    List<String> getLibriSerie (int serie);

    /**
     * Ottieni i libri appartenenti ad una collana.
     *
     * @param collana la collana in questione
     * @return i libri della collana
     */
    List<String> getLibriCollana (int collana);

    /**
     * Aggiungi disponibilita di un libro presso un canale, in una specifica modalita' di fruizione.
     *
     * @param libro    il libro
     * @param canale   il canale
     * @param modalita la modalita di fruizionne
     * @return the boolean
     */
    boolean aggiungiDisponibilita (String libro, int canale, String modalita);

    /**
     * Elimina un libro.
     *
     * @param titolo il titolo del libro
     * @return vero sero se il libro è stato eliminato correttamente, falso altrimenti
     */
    boolean eliminaLibro (String titolo);

    /**
     * Inserisci un nuovo libro.
     *
     * @param libro il libro da inserie
     * @return vero se l'inserimento è andato a buon fine, falso altrimenti.
     */
    boolean inserisciLibro(Libro libro);

    /**
     * Visualizza tutti i libri.
     *
     * @return la lista dei titoli dei libri
     */
    List<String> visualizzaLibri();
}
