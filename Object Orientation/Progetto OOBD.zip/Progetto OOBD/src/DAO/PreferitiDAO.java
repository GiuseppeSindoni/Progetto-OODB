package DAO;

import model.Serie;

import java.util.List;

/**
 * L'interfaccia Preferiti DAO.
 */
public interface PreferitiDAO {

    /**
     * Aggiungi una serie all'elenco di serie preferite di un utente.
     *
     * @param matricola la matricola dell'utente
     * @param serie la serie da aggiungere
     * @return vero se l'inserimento è andato a buon fine, falso altrimenti
     */
    boolean aggiungiSeriePreferita(int matricola, int serie);

    /**
     * Ottieni l'elenco delle serie preferite di un utete.
     *
     * @param matricola la matricola ndell'utente
     * @return la lista dei nomi delle serie preferite dell'utente
     */
    List<String> SeriePreferite(int matricola );

    /**
     * Elimina una serie dall'elenco delle serie preferite di un utente.
     *
     * @param matricola la matricola dell'utente
     * @param serie     la serie da eliminare
     * @return vero se l'eliminazione è andat a buon fine, falso altrimenti
     */
    boolean eliminaSeriePreferita(int matricola, int serie);

    /**
     * Verifica se una determinata serie fa gia parte dell'elenco di serie preferite di uno specifico utente.
     *
     * @param matricola la matricola dell'utente
     * @param codSerie  il codice della serie
     * @return vero se la serie inserite fa gia' parte dell'elenco, falso altrimenti
     */
    boolean serieGiaPreferita(int matricola, int codSerie);
}
