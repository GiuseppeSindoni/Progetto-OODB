package DAO;

import model.*;

import java.util.List;
import java.util.Map;

/**
 * L'interfaccia Pubblicazione DAO.
 */
public interface PubblicazioneDAO {

    /**
     * Cerca pubblicazioni filtrando la ricerca secondo uno specifico valore di un determinato campo.
     *
     * @param campo        il campo
     * @param searchString il valore del campo in questione
     * @return la lista di pubblicazione che soddisfano la ricerca
     */
    List<Pubblicazione> cercaPubblicazioni(String campo, String searchString);

    /**
     * Visualizza il titolo di tutte le pubblicazioni.
     *
     * @return la lista dei titoli di tuttte le pubblicazioni
     */
    List<String> visualizzaPubblicazioni();


    /**
     * Elimina una pubblicazione.
     *
     * @param titolo il titolo
     * @return vero se l'eliminazione è andata a buon fine, falso altrimenti
     */
    boolean eliminaPubblicazione (String titolo);

    /**
     * Aggiungi disponibilita di una pubblicazione presso un canale, in una specifica modalita' di fruizione.
     *
     * @param pubblicazione la pubblicazione
     * @param canale        il canale
     * @param modalita      la modalita di fruizione
     * @return the boolean
     */
    boolean aggiungiDisponibilita (String pubblicazione, int canale, String modalita);

    /**
     * Inserisci una nuova pubblicazione.
     *
     * @param p la pubblicazione da inserire.
     * @return vero se l'inseriment e' andato a buon fine.
     */
    boolean inserisciPubblicazione(Pubblicazione p);



}
