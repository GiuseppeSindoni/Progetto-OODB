package DAO;

import model.Rivista;

import java.util.List;

/**
 * L'interfaccia Rivista DAO.
 */
public interface RivistaDAO {

    /**
     * Recupera tutte le informazioni di una rivista.
     *
     * @param doi il doi della rivista
     * @return la rivista
     */
    Rivista recuperaRivistaDaDatabase(String doi);

    /**
     * Ottieni l'elenco di tutte le riviste.
     *
     * @return  l'elenco dei titoli di tutte le riviste
     */
    List<String> getElencoRiviste();
}
