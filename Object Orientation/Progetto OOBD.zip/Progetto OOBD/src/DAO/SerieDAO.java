package DAO;

import model.Serie;

import java.util.List;

/**
 * L'interfaccia Serie DAO.
 */
public interface SerieDAO {


    /**
     * Ottieni l'elenco dei nomi di tutte serie.
     *
     * @return l'elenco dei nomi di tutte le serie.
     */
    List<String> getElencoSerie();

    /**
     * Ottieni l'elenco dei codici di tutte le serie.
     *
     * @return l'elenco dei codici di tutte le serie.
     */
    List<Integer> getElencoSerieCod();

    /**
     * Cerca una serie mediante il suo codice.
     *
     * @param codSerie il codice della serie ricercata
     * @return la serie ricercata
     */
    Serie cercaSerieCod(int codSerie);

    /**
     * Effettua una ricera sulle serie, filtrando la ricerca secondo il valore di uno specifico campo.
     *
     * @param attributo    l' attributo
     * @param searchString il valore dell'attributo
     * @return the list
     */
    List<Serie> cercaSerie(String attributo, String searchString) ;




}
