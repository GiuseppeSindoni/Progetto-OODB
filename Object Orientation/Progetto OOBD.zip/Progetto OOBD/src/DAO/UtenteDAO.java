package DAO;

import model.Utente;

/**
 * L'interfaccia Utente DAO.
 */
public interface UtenteDAO {
    /**
     * Effettua login per un determinato utente, verificando che le sue credenziali esistano.
     *
     * @param matricola la matricola dell'utente
     * @param password  la password
     * @return vero se le credenziali sono corrette, falso altrimenti
     */
    boolean effettuaLogin(int matricola, String password);

    /**
     * Effettua la registrazione di un nuovo utente.
     *
     * @param matricola la matricola
     * @param password  la password
     * @param nome      il nome
     * @param cognome   il cognome
     * @param username  l'username
     * @return vero se la registrazione e' andata a buon fine falso altrimenti
     */
    boolean effettuaRegistrazione (int matricola, String password, String nome, String cognome, String username);


}