package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;

/**
 * La GUI AdminPage.
 */
public class AdminPage extends JFrame{

    private JFrame frame;
    private Controller controller;

    private JFrame loginPage;


    /**
     * Costruttore della classe.
     *
     * @param controller il controller
     * @param frame      la GUi che ha instanziato la classe admin
     */
    public AdminPage(Controller controller, JFrame frame) {
        loginPage = frame;
        this.controller = controller;
        inizializza();
    }

    /**
     * Realizza il frame principale della pagina e richiama il metodo per posizionare i vari componenti.
     */
    public void inizializza() {
        frame = new JFrame("Pagina Admin");
        frame.setSize(1000, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel pannello = new JPanel(new BorderLayout());
        frame.getContentPane().add(pannello, BorderLayout.CENTER);

        // Aggiungi un JLabel per il titolo
        JLabel titleLabel = new JLabel("Admin Page");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        pannello.add(titleLabel, BorderLayout.NORTH);

        posizionaComponenti(pannello);

        frame.setVisible(true);
    }

    private void posizionaComponenti(JPanel pannello) {

        JButton gestionePubblicazione = new JButton("Gestione Pubblicazione");
        gestionePubblicazione.setBackground(new Color(255, 255, 255));
        gestionePubblicazione.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gestionePubblicazione.addActionListener(e -> gestisciPubblicazione());

        JButton gestioneLibro = new JButton("Gestione Libro");
        gestioneLibro.setBackground(new Color(255, 255, 255));
        gestioneLibro.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gestioneLibro.addActionListener(e -> gestisciLibro());

        JPanel pannelloBottoni = new JPanel(new FlowLayout());
        pannelloBottoni.add(gestionePubblicazione);
        pannelloBottoni.add(gestioneLibro);
        pannello.add(pannelloBottoni, BorderLayout.CENTER);


        JButton logout = new JButton("Log out");
        logout.setBackground(new Color(255, 255, 255));
        logout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logout.addActionListener(e -> logout());
        pannelloBottoni.add(logout);
    }

    /**
     * Istanzia una pagina LibroGUI e chiude l'adminPage.
     */
    private void gestisciLibro() {
        new LibroGUI(controller, frame);
        frame.dispose();
    }

    /**
     * Istanzia una pagina PubblicazioneGUI e chiude l'adminPage.
     */
    private void gestisciPubblicazione () {
        new PubblicazioneGUI(controller, frame);
        frame.dispose();
    }

    /**
     * Ritorna alla pagina di Login.
     */
    private void logout () {
        frame.dispose();

        loginPage.setVisible(true);
    }
}


