package GUI;

import Controller.Controller;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

/**
 * La GUI AggiungiSerie.
 */
public class AggiungiSerie extends JFrame {

    private Controller controller;
    private int matricola;
    private SeriePreferite seriePreferiteFrame;

    /**
     * Il costruttore della classe, realizza i componenti fondamentali e visuaalizza tutte le serie presenti nel DB.
     *
     * @param controller          il controller
     * @param seriePreferiteFrame la GUI che ha instanziato AggiungiSerie
     * @param matricola           la matricola dell'utente
     */
    public AggiungiSerie(Controller controller, SeriePreferite seriePreferiteFrame, int matricola) {
        this.controller = controller;
        this.matricola = matricola;
        this.seriePreferiteFrame = seriePreferiteFrame;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        List<String> serieListData = controller.elencoSerie();

        DefaultListModel<String> serieListModel = new DefaultListModel<>();
        JList<String> serieList = new JList<>(serieListModel);

        serieList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                String serie = (String) value;
                setText(String.valueOf(serie));

                return this;
            }
        });

        for (String serie : serieListData) {
            serieListModel.addElement(serie);
        }

        JButton aggiungiButton = new JButton("Aggiungi ai preferiti");
        aggiungiButton.setBackground(new Color(255, 255, 255));
        aggiungiButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        aggiungiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aggiungiSeriePreferita(serieList.getSelectedValue());
            }
        });

        JButton backButton = new JButton("Indietro");
        backButton.setBackground(new Color(255, 255, 255));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                seriePreferiteFrame.setVisible(true);
            }
        });

        // Utilizza un GridLayout per organizzare i bottoni in una griglia
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        buttonPanel.setBackground(new Color(255, 255, 255));
        buttonPanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(aggiungiButton);
        buttonPanel.add(backButton);

        setLayout(new BorderLayout());
        add(new JScrollPane(serieList), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

    }
    /**
     * Ottiene in input la serie selezionata e la inserisce ai preferiti dell'utente.
     *
     * @param serieSelezionata la serie selezionata
     */
    private void aggiungiSeriePreferita(String serieSelezionata) {
        if (serieSelezionata != null) {
            if (!controller.aggiungiSeriePreferita(matricola, serieSelezionata)) {
                // Serie già presente nei preferiti
                JOptionPane.showMessageDialog(this, "Serie selezionata già presente nei preferiti!", "Errore", JOptionPane.ERROR_MESSAGE); return;
            } else {
                // Serie aggiunta con successo
                seriePreferiteFrame.modificaListaSeriePreferite();
                dispose();
            }
        } else {
            // Nessuna serie selezionata
            JOptionPane.showMessageDialog(this, "Seleziona una serie dalla lista.", "Errore", JOptionPane.ERROR_MESSAGE); return;
        }

        notificaUtente();
    }

    /**
     * Visualizza un avviso se vi sono canali di distribuzione che dispongono di almeno una serie preferita dell'utente.
     */
    private void notificaUtente () {
        List<List<String>> risultatiQuery = controller.visualizzaCanaliDistribuzione(matricola);

        if (!risultatiQuery.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Son disponibili tutti i volumi di una Serie preferita presso un sito e/o libreria. Visualizza nella sezione dedicata.", "Risultati Query", JOptionPane.INFORMATION_MESSAGE);

        }
    }

}
