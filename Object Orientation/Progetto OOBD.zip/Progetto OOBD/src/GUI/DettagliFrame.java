    package GUI;

    import Controller.Controller;


    import javax.swing.*;
    import java.awt.*;

    /**
     * La GUI dettagli Frame.
     */
    public class DettagliFrame extends JFrame {
        private JTextArea dettagliTextArea;

        /**
         * Costruttore della GUI.
         *
         * @param controller il controller
         * @param tipo       il tipo dell'articolo
         * @param articolo   il titolo dell' articolo
         */
        public DettagliFrame(Controller controller, String tipo ,String  articolo) {
            String dettagli = null;

            if(tipo.equals("Libro"))
                dettagli = controller.visualizzaDettagliLibro(articolo);
            else
                dettagli = controller.visualizzaDettagliPubblicazione(articolo);

            setLayoutAndDesign(dettagli, "Dettagli Articolo");
        }


        /**
         * Visualizza i dettagli di un articolo.
         *
         * @param dettagli stringa contente tutti i dettagli dell'articolo
         * @param titolo il titolo dell'articolo
         */
        private void setLayoutAndDesign(String dettagli, String titolo) {
            setLayout(new BorderLayout());

            // Crea e aggiungi i componenti per visualizzare i dettagli
            dettagliTextArea = new JTextArea();
            dettagliTextArea.setEditable(false);
            dettagliTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
            dettagliTextArea.setBackground(Color.white);

            JScrollPane scrollPane = new JScrollPane(dettagliTextArea);
            add(scrollPane, BorderLayout.CENTER);

            // Impostazioni JFrame
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setSize(400, 300);
            setLocationRelativeTo(null);
            setVisible(true);

            dettagliTextArea.setText(dettagli);
            setTitle(titolo);
        }
    }
