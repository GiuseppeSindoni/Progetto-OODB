package GUI;

import Controller.Controller;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;


/**
 * La GUI Home page.
 */
public class HomePage extends JFrame {

    private Controller controller;
    private int matricola;

    private DefaultListModel<String> pubblicazioniListModel;
    private JList<String> pubblicazioniList;

    private DefaultListModel<String> libriListModel;
    private JList<String> libriList;

    private JPanel sideBar;

    private JFrame loginPage;

    private boolean sideBarVisible = false;

    /**
     * Costruttore della GUI, Realizza e inserisce tutti i componenti all'interno dell'interfaccia.
     *
     * @param controller il controller
     * @param matricola  la matricola dell'utente che ha effettuato il login
     * @param frame      la GUI che ha istanziato HomePage
     */
    public HomePage(Controller controller, int matricola, JFrame frame) {
        this.loginPage = frame;
        this.controller = controller;
        this.matricola = matricola;

        JButton logOutButton = new JButton("Log Out");
        logOutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logOutButton.setBackground(new Color(255, 255, 255));
        logOutButton.addActionListener(e -> chiudiHomePage());

        JTextField searchField = new JTextField(20);
        JButton cercaButton = new JButton("Cerca");
        cercaButton.addActionListener(e -> ricerca(searchField.getText().trim()));
        cercaButton.setBackground(new Color(255, 255, 255));
        cercaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton seriePreferiteButton = new JButton("Preferiti");
        seriePreferiteButton.addActionListener(e -> apriSeriePreferiteGUI());
        seriePreferiteButton.setBackground(new Color(255, 255, 255));
        seriePreferiteButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton canaliButton = new JButton("Visualizza Canali");
        canaliButton.addActionListener(e -> mostraCanaliDisponibilitaSerie());
        canaliButton.setBackground(new Color(255, 255, 255));
        canaliButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton collanatButton = new JButton("Collane");
        collanatButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        collanatButton.setBackground(new Color(255, 255, 255));
        collanatButton.addActionListener(e -> apriCollane());

        ImageIcon sideBarIcon = new ImageIcon("img/user.jpg");

        pubblicazioniListModel = new DefaultListModel<>();
        pubblicazioniList = new JList<>(pubblicazioniListModel);
        configuraJList(pubblicazioniList);

        libriListModel = new DefaultListModel<>();
        libriList = new JList<>(libriListModel);
        configuraJList(libriList);

        JScrollPane searchResultsScrollPane = new JScrollPane(libriList);

        JScrollPane pubblicazioniScrollPane = new JScrollPane(pubblicazioniList);

        JPanel listsPanel = new JPanel(new GridLayout(1, 2));
        listsPanel.add(pubblicazioniScrollPane);
        listsPanel.add(searchResultsScrollPane);

        JPanel searchPanel = new JPanel(new BorderLayout());
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(cercaButton, BorderLayout.EAST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(canaliButton);
        buttonPanel.add(collanatButton);

        JPanel navigationPanel = new JPanel();
        navigationPanel.setLayout(new GridLayout(15, 1));

        navigationPanel.add(seriePreferiteButton);
        navigationPanel.add(logOutButton);

        sideBar = new JPanel();
        sideBar.setLayout(new BorderLayout());
        sideBar.setBackground(Color.LIGHT_GRAY);
        sideBar.setPreferredSize(new Dimension(150, getHeight()));

        JButton sideBarButton = new JButton(sideBarIcon);
        sideBarButton.addActionListener(e -> gestisciBarraLaterale());

        sideBarButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sideBarButton.setPreferredSize(new Dimension(sideBarIcon.getIconWidth(), sideBarIcon.getIconHeight()));
        searchPanel.add(sideBarButton, BorderLayout.WEST);

        setLayout(new BorderLayout());
        add(searchPanel, BorderLayout.NORTH);
        add(listsPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 800);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

        add(sideBar, BorderLayout.WEST);
        sideBar.add(navigationPanel, BorderLayout.CENTER);
        sideBar.setVisible(false);

        visualizzaArticoli();
        notificaUtente();

        libriList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                gestisciMouseElenco(libriList, e, "Libro");
            }
        });

        pubblicazioniList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                gestisciMouseElenco(pubblicazioniList, e, "Pubblicazione");
            }
        });
    }

    private void configuraJList(JList<String> list) {
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(10);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                if (value instanceof String) {
                    JLabel renderer = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    renderer.setToolTipText((String) value);
                    return renderer;
                } else {
                    return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                }
            }
        });
    }

    private void gestisciMouseElenco (JList<String> list, MouseEvent e, String tipo) {
        int index = list.locationToIndex(e.getPoint());

        if (SwingUtilities.isLeftMouseButton(e)) {
            if (index != -1) {
                list.setSelectedIndex(index);
            }
        } else if (SwingUtilities.isRightMouseButton(e)) {
            if (list.getSelectedIndex() != -1 && index == list.getSelectedIndex()) {
                visualizzaDettagliConBottone(e.getPoint(), tipo, list);
            }
        }
    }



    /**
     * Chiude la home page e riapre LoginPage.
     */
    private void chiudiHomePage () {
        dispose();
        loginPage.setVisible(true);
    }


    private void gestisciBarraLaterale() {
        sideBarVisible = !sideBarVisible;
        sideBar.setVisible(sideBarVisible);
    }

    /**
     * Realizza i bottoni per visualizzare i dettagli e la disponibilita' dell'articolo selezionato
     *
     * @param  tipo il tipo dell'articolo (Libro, Pubblicazione)
     * @param  list la lista dove prelevare l'elemento selezionato
     */
    private void visualizzaDettagliConBottone(Point point, String tipo, JList list) {
        int index = list.getSelectedIndex();
        if (index != -1) {
            Object selectedObject = list.getModel().getElementAt(index);
            if (selectedObject != null) {
                JButton dettagliButton = new JButton("     Dettagli    ");
                dettagliButton.setBackground(new Color(255, 255, 255));
                dettagliButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

                JButton disponibilitaButton = new JButton("Disponibilità");
                disponibilitaButton.setBackground(new Color(255, 255, 255));
                disponibilitaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

                JPopupMenu popupMenu = new JPopupMenu();
                popupMenu.add(dettagliButton);
                popupMenu.add(disponibilitaButton);

                dettagliButton.addActionListener(e -> visualizzaDettagliSelezionato( tipo, list ));
                disponibilitaButton.addActionListener(e -> visualizzaDisponibilitaSelezionato( tipo,  list));

                popupMenu.show(list, point.x, point.y);
            }
        }
    }



    /**
     * Visualizza dove e' disponbile, e in quali modalita di fruizione, l'articolo selezionato.
     *
     * @param tipo il tipo dell'articolo (Libro, Pubblicazione)
     * @param list  la lista da dove prelevare l'elemento selezionato
     */

    private void visualizzaDisponibilitaSelezionato(String tipo, JList list) {
        String selectedObject = (String) list.getSelectedValue();

        if (selectedObject != null) {
            Map<String, Set<String>> risultatiStringa = controller.disponibilita(selectedObject, tipo);

            if (!risultatiStringa.isEmpty()) {
                JFrame popupFrame = new JFrame("Canali di distribuzione");
                popupFrame.setSize(300, 200);
                popupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                DefaultListModel<String> resultListModel = new DefaultListModel<>();
                JList<String> resultList = new JList<>(resultListModel);
                JScrollPane scrollPane = new JScrollPane(resultList);

                // Aggiungi le coppie nome del canale - modalità di fruizione alla lista
                for (Map.Entry<String, Set<String>> entry : risultatiStringa.entrySet()) {
                    String nomeCanale = entry.getKey();
                    Set<String> modalitaFruizione = entry.getValue();
                    String item = nomeCanale + " - " + modalitaFruizione.toString();
                    resultListModel.addElement(item);
                }

                popupFrame.add(scrollPane);
                popupFrame.setLocationRelativeTo(this);
                popupFrame.setVisible(true);

                popupFrame.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        if (popupFrame != null && popupFrame.isShowing()) {
                            popupFrame.dispose();
                        }
                    }
                });
            } else {
                JOptionPane.showMessageDialog(this, "L'articolo selezionato al momento non è disponibile su alcuna piattaforma", "Errore", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    /**
     * Istanzia una pagina DettagliFrame .
     *
     * @param tipo il tipo dell'articolo selezionato
     * @param list la lista dove prelevare l'elemento selezionato
     */

    private void visualizzaDettagliSelezionato( String tipo, JList list) {
        String selectedObject = (String) list.getSelectedValue();

        if (selectedObject != null) {
            new DettagliFrame(this.controller, tipo, selectedObject) {
                @Override
                public void dispose() {
                    super.dispose();
                }
            };
        }

    }
    /**
     * Istanzia la Pagina SeriePreferite
     */
    private void apriSeriePreferiteGUI() {
        new SeriePreferite(controller, this, matricola);
    }

    /**
     * Effettua una ricerca sugli articoli mediante il titolo, aggiorna le liste conseguentemente alla ricerca effettuata
     *
     * @param searchString il contenuto digitato nella barra di ricerca
     */
    private void ricerca(String searchString) {
        List<List<String>> articoli = controller.cercaArticoli("titolo", searchString);

        aggiornaLista(articoli.get(0), libriListModel);
        aggiornaLista(articoli.get(1), pubblicazioniListModel);
    }

    /**
     * Visualizza tutti gli articoli presenti nel DB, inserendoli in due liste diverse, una per ogni tipo di articolo.
     */
    private void visualizzaArticoli() {
        List<String> risultatiLibri = controller.visualizzaLibri();
        List<String> risultatiPubblicazioni = controller.visualizzaPubblicazioni();

        aggiornaLista(risultatiLibri, libriListModel);
        aggiornaLista(risultatiPubblicazioni, pubblicazioniListModel);
    }

    /**
     * Data una lista di titoli di articoli e una lista, aggiorna la lista inserendo tutti gli articoli al suo interno
     *
     * @param articoli la lista di articoli
     * @param  listModel la lista nella quale inserire gli elementi
     */
    private void aggiornaLista(List<String> articoli, DefaultListModel<String> listModel) {
        listModel.clear();

        for (String articolo : articoli) {
            listModel.addElement(articolo);
        }

        if (listModel.isEmpty()) {
            listModel.addElement("Nessun risultato trovato.");
        }
    }





    /**
     * Mostra, all'interno di un opportuno frame, i canali che dispongono di almeno una serie preferita dell'utente.
     */
    private void mostraCanaliDisponibilitaSerie () {
        List<List<String>> risultatiQuery = controller.visualizzaCanaliDistribuzione(matricola);
        List<String> risultatiStringa = new ArrayList<>();

        for (List<String> entry : risultatiQuery) {

            risultatiStringa.add(  entry.get(0) + " - "  + entry.get(1));
        }

        if (!risultatiStringa.isEmpty()) {
            JFrame popupFrame = new JFrame("Canali Distribuzione");
            popupFrame.setSize(400, 300);
            popupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JList<String> resultList = new JList<>(risultatiStringa.toArray(new String[0]));
            JScrollPane scrollPane = new JScrollPane(resultList);

            popupFrame.add(scrollPane);
            popupFrame.setLocationRelativeTo(this);
            popupFrame.setVisible(true);



            popupFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    if (popupFrame != null && popupFrame.isShowing()) {
                        popupFrame.dispose();
                    }
                }
            });
        }
        else {
            JOptionPane.showMessageDialog(this, "Attualmente presso nessun canale di distribuzione è disponibile una tua serie preferita. Verifica di avere delle serie nella sezione 'Preferiti'. ", "Attenzione",JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Realizza un frame dove visualizzare tutte le collane presenti nel DB (nome collana - editore) e permette di visualizzare tutti i libri appartenenti alla collana mediante il bottone apposito
     */
    private void apriCollane() {
        List<String> risultatiStringa = controller.getCollane();



        if (!risultatiStringa.isEmpty()) {
            JFrame popupFrame = new JFrame("Collane");
            popupFrame.setSize(400, 300);
            popupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


            JList<String> resultList = new JList<>(risultatiStringa.toArray(new String[0]));
            JScrollPane scrollPane = new JScrollPane(resultList);

            JButton visualizzaLibriButton = new JButton("Visualizza Libri");
            visualizzaLibriButton.setBackground(new Color(255, 255, 255));
            visualizzaLibriButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            visualizzaLibriButton.addActionListener(e -> visualizzaLibriAssociati(resultList.getSelectedValue()));

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.add(visualizzaLibriButton);

            popupFrame.add(scrollPane, BorderLayout.CENTER);
            popupFrame.add(buttonPanel, BorderLayout.SOUTH);
            popupFrame.setLocationRelativeTo(this);
            popupFrame.setVisible(true);

            popupFrame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    if (popupFrame != null && popupFrame.isShowing()) {
                        popupFrame.dispose();
                    }
                }
            });
        } else {
            JOptionPane.showMessageDialog(this, "Attualmente non esiste alcuna Collana. ", "Attenzione", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Visualizza i libri appartenenti ad una collana, e permette di visualizzare i dettagli di ogni libro
     *
     * @param collanaSelezione la collana seleionata
     */
    private void visualizzaLibriAssociati(String collanaSelezione) {
        if (collanaSelezione != null) {

            String[] parts = collanaSelezione.split(" - ");
            String nomeCollana = parts[0];

            List<String> libriAssociati = controller.getLibriCollana(nomeCollana);

            if (!libriAssociati.isEmpty()) {


                JFrame libriFrame = new JFrame("Libri Associati a " + nomeCollana);
                libriFrame.setSize(400, 300);
                libriFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JList<String> resultList = new JList<>(libriAssociati.toArray(new String[0]));
                JScrollPane scrollPane = new JScrollPane(resultList);

                libriFrame.add(scrollPane);
                libriFrame.setLocationRelativeTo(this);
                libriFrame.setVisible(true);

                resultList.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent evt) {
                        if (evt.getClickCount() == 2) { // Doppio clic
                            // Ottieni il libro selezionato
                            String nomeLibroSelezionato = resultList.getSelectedValue();

                            // Apri il DettagliFrame
                            if (nomeLibroSelezionato != null) {
                                new DettagliFrame(controller, "Libro", nomeLibroSelezionato);
                            }
                        }
                    }
                });

                libriFrame.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        if (libriFrame != null && libriFrame.isShowing()) {
                            libriFrame.dispose();
                        }
                    }
                });
            } else {
                JOptionPane.showMessageDialog(this, "Nessun libro associato a questa collana.", "Attenzione", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleziona una collana.", "Attenzione", JOptionPane.WARNING_MESSAGE);
        }
    }






    /**
     * Notifica l'utente nel momento in cui vi sono canali che dispongono di un intera serie preferita dell'utente.
     */

    private void notificaUtente() {
        List<List<String>> risultatiQuery = controller.visualizzaCanaliDistribuzione(matricola);

        if (!risultatiQuery.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Sono disponibili tutti i volumi di una Serie preferita presso un sito e/o libreria. Visualizza nella sezione dedicata.", "Attenzione ", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
