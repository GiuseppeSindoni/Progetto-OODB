package GUI;



import Controller.Controller;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.toedter.calendar.JDateChooser;

/**
 * La GUI LibroGUI.
 */
public class LibroGUI {

    private JFrame frame;

    private DefaultListModel<String> libriListModel;
    private JList<String> libriList;
    private Controller controller;

    private JFrame aggiungiLibroFrame;

    private JFrame adminPage;

    private JCheckBox cartaceoCheckBox;
    private JCheckBox digitaleCheckBox;
    private JCheckBox audiolibroCheckBox;

    /**
     * Costruttore della classe.
     *
     * @param controller il controller
     * @param frame      la GUi che ha istanziato LoginPage
     */
    public LibroGUI (Controller controller, JFrame frame) {
        this.controller = controller;
        adminPage = frame;
        inizializza();


    }

    /**
     * Realizza il frame principale dell'interfaccia e visualizza tutti i libri del sistema
     */
    private void inizializza() {
        frame = new JFrame("Pagina Admin - Libro");
        frame.setSize(1000, 800);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel pannello = new JPanel(new BorderLayout());
        frame.getContentPane().add(pannello, BorderLayout.CENTER);
        posizionaComponenti();

        libriListModel = new DefaultListModel<>();
        libriList = new JList<>(libriListModel);
        configuraJList(libriList);

        JScrollPane scrollPane = new JScrollPane(libriList);
        pannello.add(scrollPane, BorderLayout.CENTER);

        visualizzaArticoli(); // Aggiorna la lista inizialmente
        frame.setVisible(true);
    }

    /**
     * Restituisce la lista dei titoli di tutti i libri presenti nel database
     */
    private void visualizzaArticoli() {
        List<String> risultatiLibri = controller.visualizzaLibri();
        aggiornaLista(risultatiLibri, libriListModel);
    }

    /**
     * Inserisce all'interno della lista il titolo di tutti gli articoli dati in input.
     *
     * @param articoli i titoli degli articoli da inserire
     * @param listModel la lista dove inserire gli articoli
     */
    private void aggiornaLista(List<String> articoli, DefaultListModel<String> listModel) {
        listModel.clear();

        for (String articolo : articoli) {
            listModel.addElement(articolo);
        }

        if (listModel.isEmpty()) {
            listModel.addElement("Nessun risultato trovato.");
        }
    }


    private void configuraJList(JList<String> list) {
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(10);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                if (value instanceof String) {
                    JLabel renderer = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    renderer.setToolTipText((String) value);
                    return renderer;
                } else {
                    return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                }
            }
        });




    }

    /**
     * Posiziona tutti i bottoni all'interno del pannello apposito, e definisce i comportamenti nel caso i bottoni vengano cliccati.
     */
    private void posizionaComponenti() {
        JButton bottoneAggiungiLibro = new JButton("Aggiungi Libro");
        bottoneAggiungiLibro.setBackground(new Color(255, 255, 255));
        bottoneAggiungiLibro.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bottoneAggiungiLibro.addActionListener(e -> gestisciAggiungiLibro());

        JButton bottoneEliminaLibro = new JButton("Elimina Libro");
        bottoneEliminaLibro.setBackground(new Color(255, 255, 255));
        bottoneEliminaLibro.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bottoneEliminaLibro.addActionListener(e -> gestisciEliminaLibro());

        JButton disponibilitaButton = new JButton("Aggiungi disponibilità");
        disponibilitaButton.setBackground(new Color(255, 255, 255));
        disponibilitaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        disponibilitaButton.addActionListener(e -> aggiungiDisponibilitaLibro());

        JButton indietroButton = new JButton("Indietro");
        indietroButton.setBackground(new Color(255, 255, 255));
        indietroButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        indietroButton.addActionListener(e -> tornaAdminPage());


        JPanel pannelloBottoni = new JPanel(new FlowLayout());
        pannelloBottoni.add(bottoneAggiungiLibro);
        pannelloBottoni.add(bottoneEliminaLibro);
        pannelloBottoni.add(disponibilitaButton);
        pannelloBottoni.add(indietroButton);

        frame.getContentPane().add(pannelloBottoni, BorderLayout.SOUTH);



    }

    /**
     * Chiude l'interfaccia riaprendo AdminPage.
     */
    private void tornaAdminPage() {
        frame.dispose();

        adminPage.setVisible(true);
    }

    /**
     * Realizza un frame per l'aggiunta della disponibilita del libro selezionato presso un canale in una specifica modalita, fornisce due ComboBox per la scelta del canale e della modalita.
     */
    private void aggiungiDisponibilitaLibro() {
        JFrame f = new JFrame("Aggiungi Libro");
        f.setSize(400, 200);
        f.setLayout(new GridLayout(0, 2));
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setLocationRelativeTo(null);

        String libro = libriList.getSelectedValue();

        if (libro != null) {
            f.setVisible(true);

            JLabel label = new JLabel("Seleziona il canale di distribuzione:");
            f.add(label);

            List<String> canaliList = controller.visualizzaCanali();
            ComboBoxModel<String> canaliComboBoxModel = new DefaultComboBoxModel<>(canaliList.toArray(new String[0]));

            JComboBox<String> canaliComboBox = new JComboBox<>(canaliComboBoxModel);
            f.add(canaliComboBox);

            Set<String> modalita = controller.getModalitaFruizioneLibro(libro);

            if (modalita != null) {

                JLabel labelModalita = new JLabel("Seleziona la modalità di fruizione:");
                f.add(labelModalita);

                JComboBox<String> modalitaFruizione = new JComboBox<>(modalita.toArray(new String[0]));
                f.add(modalitaFruizione);

                JButton confermaButton = new JButton("Conferma");
                confermaButton.setBackground(new Color(255, 255, 255));
                confermaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                confermaButton.addActionListener(e -> {

                    try {
                        String selectedCanale = (String) canaliComboBox.getSelectedItem();
                        String selectedModalita = (String) modalitaFruizione.getSelectedItem();

                        if (selectedCanale == null || selectedModalita == null) {
                            JOptionPane.showMessageDialog(f, "Seleziona un canale e una modalità di fruizione.");
                        }
                        else if(controller.verificaDisponibilitaLibro(libro, selectedCanale, selectedModalita))
                                JOptionPane.showMessageDialog(f, "Libro gia disponibile presso " + selectedCanale + " nel formato:" + selectedModalita);

                            else if (controller.aggiungiDisponibilitaLibro(libro, selectedCanale, selectedModalita)) {
                                    JOptionPane.showMessageDialog(f, "Disponibilità aggiunta con successo");

                                } else {
                                    JOptionPane.showMessageDialog(f, "Errore durante l'inserimento.");
                                    }
                        f.dispose();
                    } catch (Exception ex) {
                        ex.printStackTrace(); // Print the exception for debugging
                        JOptionPane.showMessageDialog(f, "Errore generico durante l'operazione.");
                    }
                });
                f.add(confermaButton);
            } else {
                JOptionPane.showMessageDialog(f, "Errore: Modalità di fruizione non disponibili.");
                f.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(f, "Seleziona prima un libro.");
            f.dispose();
        }
    }


    /**
     * Realizza un frame per l'inserimento di un nuovo libro, realizzando un form dove inserire tutte le informazioni e permettendo di inserire solo specifici formati in base al campo.
     */
    private void gestisciAggiungiLibro() {
        aggiungiLibroFrame = new JFrame("Aggiungi Libro");
        aggiungiLibroFrame.setSize(600, 450);
        aggiungiLibroFrame.setLayout(new GridLayout(0, 2));
        aggiungiLibroFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        aggiungiLibroFrame.setLocationRelativeTo(null);

        // Componenti per l'inserimento delle informazioni
        JLabel isbnLabel = new JLabel("ISBN:");
        JTextField isbnField = new JTextField();

        JLabel titoloLabel = new JLabel("Titolo:");
        JTextField titoloField = new JTextField();
        consentiSoloLettere(titoloField);

        JLabel tipoLabel = new JLabel("Tipo:");
        String[] tipiLibro = {"Didattico", "Romanzo"};
        JComboBox<String> tipoComboBox = new JComboBox<>(tipiLibro);

        JLabel editoreLabel = new JLabel("Editore:");
        JTextField editoreField = new JTextField();
        consentiSoloLettere(editoreField);

        JLabel salaLabel = new JLabel("Sala presentazione:");
        JTextField salaField = new JTextField();
        consentiSoloLettere(salaField);

        JLabel dataLabel = new JLabel("Data Uscita:");
        JDateChooser dataChooser = new JDateChooser();
        dataChooser.setDateFormatString("dd/MM/yyyy");


        JLabel modalitaFruizioneLabel = new JLabel("Modalità fruizione:");
        JPanel modalitaFruizionePanel = new JPanel(); // Pannello per contenere i radio button

        cartaceoCheckBox = new JCheckBox("Cartaceo");
        digitaleCheckBox = new JCheckBox("Digitale");
        audiolibroCheckBox = new JCheckBox("Audiolibro");

        // Aggiunta dei checkbox al pannello
        modalitaFruizionePanel.setLayout(new GridLayout(3, 1));
        modalitaFruizionePanel.add(cartaceoCheckBox);
        modalitaFruizionePanel.add(digitaleCheckBox);
        modalitaFruizionePanel.add(audiolibroCheckBox);

        JLabel serieLabel = new JLabel("Serie:");
        Integer[] elencoSerieCod = controller.elencoSerieCod().toArray(new Integer[0]);
        Integer[] elencoCompleto = new Integer[elencoSerieCod.length + 1];
        System.arraycopy(elencoSerieCod, 0, elencoCompleto, 1, elencoSerieCod.length);
        elencoCompleto[0] = null; // Aggiungi un'opzione per "Nessuna serie"
        JComboBox<Integer> serieComboBox = new JComboBox<>(elencoCompleto);


        JLabel autoreLabel = new JLabel("Autore:");
        JTextField autoreField = new JTextField();

        JButton confermaButton = new JButton("Conferma");
        confermaButton.setBackground(new Color(255, 255, 255));
        confermaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        confermaButton.addActionListener(e -> aggiungiLibro(isbnField.getText(), titoloField.getText(), tipoComboBox.getSelectedItem(),
                editoreField.getText(), salaField.getText(), (Date) dataChooser.getDate(),
                 serieComboBox.getSelectedItem(),
                autoreField.getText()));

        // Aggiunta dei componenti al frame
        aggiungiLibroFrame.add(isbnLabel);
        aggiungiLibroFrame.add(isbnField);
        aggiungiLibroFrame.add(titoloLabel);
        aggiungiLibroFrame.add(titoloField);
        aggiungiLibroFrame.add(tipoLabel);
        aggiungiLibroFrame.add(tipoComboBox);
        aggiungiLibroFrame.add(editoreLabel);
        aggiungiLibroFrame.add(editoreField);
        aggiungiLibroFrame.add(salaLabel);
        aggiungiLibroFrame.add(salaField);
        aggiungiLibroFrame.add(dataLabel);
        aggiungiLibroFrame.add(dataChooser);
        aggiungiLibroFrame.add(modalitaFruizioneLabel);
        aggiungiLibroFrame.add(modalitaFruizionePanel);
        aggiungiLibroFrame.add(serieLabel);
        aggiungiLibroFrame.add(serieComboBox);
        aggiungiLibroFrame.add(autoreLabel);
        aggiungiLibroFrame.add(autoreField);
        aggiungiLibroFrame.add(confermaButton);

        aggiungiLibroFrame.setVisible(true);
    }


    /**
     * Prende in input tutte le informazioni del libro ed effettua tutti i controlli del caso per far si che l'inserimento avvenga correttamente.
     *
     * @param isbn       l'isbn
     * @param titolo     il titolo
     * @param tipo       il tipo (Didattico, Romanzo)
     * @param editore    l'editore
     * @param sala       la sala
     * @param dataUscita la data uscita
     * @param serie      la serie
     * @param autore     il\gli autore
     */
    public void aggiungiLibro(String isbn, String titolo, Object tipo, String editore, String sala, Date dataUscita, Object serie, String autore) {
        if (isbn.equals("") || titolo.equals("") || tipo == null || editore.equals("") || dataUscita == null ) {
            JOptionPane.showMessageDialog(aggiungiLibroFrame, "Compila tutti i campi del form.");
        } else {
                // Validazione specifica dei campi come ISBN, anno di pubblicazione, ecc.
                if (!isValidISBN(isbn)) {
                    JOptionPane.showMessageDialog(aggiungiLibroFrame, "Formato ISBN non valido.");
                } else {
                    // Conversione dei tipi con try-catch
                    if (controller.cercaLibro("isbn", isbn)) {
                        JOptionPane.showMessageDialog(aggiungiLibroFrame, "L'ISBN inserito appartiene già ad un altro libro.");
                    } else if (controller.cercaLibro("titolo", titolo)) {
                        JOptionPane.showMessageDialog(aggiungiLibroFrame, "Il titolo inserito appartiene già ad un altro libro.");
                    } else {
                        String tipoLibro = (String) tipo;
                        Integer numeroSerie = null;

                        if (serie == null)
                            numeroSerie = -1;
                        else
                            numeroSerie = (Integer) serie;

                        Set<String> modalitaFruizioneSet =  getModalitaFruizioneSelezionate();
                        if (modalitaFruizioneSet.isEmpty()) {
                            JOptionPane.showMessageDialog(aggiungiLibroFrame, "Seleziona almeno una modalità di fruizione.");
                            return;
                        }
                        if (!(tipo.equals("Didattico") && serie != null)) {
                            // Controllo sulle modalità di fruizione
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(dataUscita);
                            int annoPubblicazione = calendar.get(Calendar.YEAR);

                            Set<String> autori = new HashSet<>(Arrays.asList(autore.split("\\s*,\\s*")));

                            if(autore.length() < 2){
                                JOptionPane.showMessageDialog(aggiungiLibroFrame, "Inserisci almeno un autore"); return;
                            }

                            if (controller.aggiungiLibro(isbn, titolo, tipoLibro, editore, sala, dataUscita, annoPubblicazione, modalitaFruizioneSet, numeroSerie,  autori)) {
                                JOptionPane.showMessageDialog(aggiungiLibroFrame, "Libro aggiunto con successo.");
                                aggiornaLista(controller.visualizzaLibri(), libriListModel);
                                aggiungiLibroFrame.dispose();
                            } else {
                                JOptionPane.showMessageDialog(aggiungiLibroFrame, "Errore durante l'aggiunta del libro.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(aggiungiLibroFrame, "Un libro Didattico non può appartenere ad una serie!");
                        }
                    }
                }

        }
    }

    /**
     * Aggiunge ad un elenco tutte le modalita di fruizione selezionate per l'inserimento di un libro.
     *
     * @return  le modalita di fruizione che sono state selezionate
     */
    private Set<String> getModalitaFruizioneSelezionate() {
        Set<String> modalitaFruizioneSet = new HashSet<>();
        if (cartaceoCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Cartaceo");
        }
        if (digitaleCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Digitale");
        }
        if (audiolibroCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Audiolibro");
        }
        return modalitaFruizioneSet;
    }


    /**
     * Richiama il metodo per eliminare il libro selezionato e aggiorna la lista dei libri post cancellazione.
     */
    private void gestisciEliminaLibro() {
        // Ottieni il libro selezionato
        String libroSelezionato = libriList.getSelectedValue();
        if (libroSelezionato != null) {
            // Chiamata al metodo per eliminare il libro
            controller.eliminaLibro(libroSelezionato);
            aggiornaLista(controller.visualizzaLibri(), libriListModel);
        } else {
            JOptionPane.showMessageDialog(frame, "Seleziona un libro da eliminare.");
        }
    }

    /**
     * Peremette di inserire solamente lettere.
     */
    private void consentiSoloLettere(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("[a-zA-Z ]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    /**
     * Verifica se il formato dell'isbn inserito e' corretto.
     *
     * @param isbn l'isbn
     * @return vero se il formato e' corretto, falso altrimento
     */
    public  boolean isValidISBN(String isbn) {
        // Espressione regolare per ISBN-13
        String regex = "^(97[89])?\\d{9}(\\d|X)$";

        // Crea un oggetto Pattern
        Pattern pattern = Pattern.compile(regex);

        // Crea un oggetto Matcher con l'ISBN fornito
        Matcher matcher = pattern.matcher(isbn);

        // Verifica se c'è una corrispondenza
        return matcher.matches();
    }



}
