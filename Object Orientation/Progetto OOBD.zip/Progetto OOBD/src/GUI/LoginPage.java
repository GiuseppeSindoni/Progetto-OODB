package GUI;

import DAO.UtenteDAO;
import Controller.Controller;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * La GUI LoginPage.
 */
public class LoginPage extends JFrame {
    private JTextField matricolaField;
    private JPasswordField passwordField;

    private Controller controller;

    /**
     * Costruttore della classe, realizza l'interfaccia contente le label per inserire matricola e password e i vari tasti.
     */
    public LoginPage() {
        super("Login Page");

        // Crea un'istanza di Controller e assegnala all'attributo della classe
        controller = new Controller();


        // Creazione dei componenti
        JLabel matricolaLabel = new JLabel("Matricola:");
        JLabel passwordLabel = new JLabel("Password:");

        matricolaField = new JTextField(20);
        consentiSoloNumeri(matricolaField); // Applica il filtro per consentire solo cifre numeriche

        passwordField = new JPasswordField(20);

        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(255, 255, 255));
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });


        JButton registerButton = new JButton("Registrati");
        registerButton.setBackground(new Color(255, 255, 255));
        registerButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {apriRegistrationPage();
            }
        });

        // Creazione del layout
        //setLayout(new GridLayout(5, 2));
        setLayout(new FlowLayout(FlowLayout.CENTER));

        // Aggiunta dei componenti al layout
        add(matricolaLabel);
        add(matricolaField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        add(registerButton);

        // Impostazioni JFrame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 187);
        setLocationRelativeTo(null); // Centra la finestra
        setResizable(false);
        setVisible(true);
    }

    /**
     * Istanzia l'AdminPage e chiude la LoginPage.
     */
    public void loginAdmin() {
        dispose();


        passwordField.setText("");
        matricolaField.setText("");

        new AdminPage(controller, this);
    }


    /**
     * Consente di inserire solamente numeri
     */
    private void consentiSoloNumeri(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("-?\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }


    /**
     * Preleva le informazioni inserite, effettua il login o meno in base alla correttezza dei dati inseriti, in caso di credenziali corrette richiama i metodi per istanziare AdimnPage oppure HomePage
     */
    private void login() {
        int matricola;
        String matricolaText = matricolaField.getText().trim();  // Rimuove gli spazi bianchi
        if (matricolaText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Inserisci una matricola valida.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            matricola = Integer.parseInt(matricolaText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Inserisci una matricola valida.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return;
        }


        String password = new String(passwordField.getPassword());

        if( matricola == -1 && password.equals("admin")) {
            loginAdmin();

        } else if( controller.effettuaLogin(matricola, password))
                    apriHomePage(matricola);
                else
                    JOptionPane.showMessageDialog(this, "Credenziali non valide. Riprova.");

    }


    /**
     * Istanzia la GUI RegistrationPage
     */
    private void apriRegistrationPage() {
        // Passa l'istanza di Controller alla RegistrationPage
        new RegistrationPage(controller, this);
    }


    /**
     * Chiude LoginPage e istanzia HomaPage
     */
    private void apriHomePage(int matricola) {
        // Chiudi la finestra di login
        dispose();

        // Pulisci i campi della finestra di login
        passwordField.setText("");
        matricolaField.setText("");

        // Apri la finestra home passando l'istanza di Controller e la matricola
        new HomePage(controller, matricola, this);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginPage();
            }
        });
    }

}