package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * La GUI PubblicazioneGUI.
 */
public class PubblicazioneGUI {

    private JFrame frame;

    private DefaultListModel<String> pubblicazioneListModel;
    private JList<String> pubblicazioneList;
    private Controller controller;

    private JFrame aggiungiPubblicazioneFrame;

    private  JFrame adminPage;

    private JCheckBox cartaceoCheckBox;
    private JCheckBox digitaleCheckBox;
    private JCheckBox audiolibroCheckBox;


    /**
     * Costruttore della classe.
     *
     * @param controller il controller
     * @param frame      la GUI che ha instanziato PubblicazioneGUI
     */
    public PubblicazioneGUI (Controller controller, JFrame frame) {
        this.controller = controller;
        adminPage = frame;
        inizializza();
    }

    /**
     * Realizza il frame principale insieme alla lista contenente tutte le pubblicazioni del sistema
     */
    public void inizializza() {
        frame = new JFrame("Pagina Admin - Pubblicazione");
        frame.setSize(1000, 800);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel pannello = new JPanel(new BorderLayout());
        frame.getContentPane().add(pannello, BorderLayout.CENTER);
        posizionaComponenti();

        pubblicazioneListModel = new DefaultListModel<>();
        pubblicazioneList = new JList<>(pubblicazioneListModel);
        configuraJList(pubblicazioneList);

        JScrollPane scrollPane = new JScrollPane(pubblicazioneList);
        pannello.add(scrollPane, BorderLayout.CENTER);

        visualizzaArticoli(); // Aggiorna la lista inizialmente
        frame.setVisible(true);
    }


    /**
     * Preleva tutti i titoli delle pubblicazioni presenti nel DB e richiama il metodo per aggiornare lista
     */
    private void visualizzaArticoli() {
        List<String> risultatiLibri = controller.visualizzaPubblicazioni();
        aggiornaLista(risultatiLibri, pubblicazioneListModel);
    }

    /**
     * Svuota inizialmente la lista e inserisce tutti i titoli degli articoli dati in input.
     *
     * @param  articoli i titoli degli articoli
     * @param listModel lista dove inserire i titoli degli articoli
     */
    private void aggiornaLista(List<String> articoli, DefaultListModel<String> listModel) {
        listModel.clear();

        for (String articolo : articoli) {
            listModel.addElement(articolo);
        }

        if (listModel.isEmpty()) {
            listModel.addElement("Nessun risultato trovato.");
        }
    }

    private void configuraJList(JList<String> list) {
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(10);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                if (value instanceof String) {
                    JLabel renderer = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    renderer.setToolTipText((String) value);
                    return renderer;
                } else {
                    return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                }
            }
        });



    }


    /**
     * Realizza i vari bottoni, ne definisce i comportamenti nel caso vengano cliccati e li aggiunge al pannello
     */
    private void posizionaComponenti() {
        JButton bottoneAggiungiPubblicazione = new JButton("Aggiungi Pubblicazione");
        bottoneAggiungiPubblicazione.setBackground(new Color(255, 255, 255));
        bottoneAggiungiPubblicazione.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bottoneAggiungiPubblicazione.addActionListener(e -> gestisciAggiungiPubblicazione());

        JButton bottoneEliminaPubblicazione = new JButton("Elimina Pubblicazione");
        bottoneEliminaPubblicazione.setBackground(new Color(255, 255, 255));
        bottoneEliminaPubblicazione.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bottoneEliminaPubblicazione.addActionListener(e -> gestisciEliminaPubblicazione());

        JButton disponibilitaButton = new JButton("Aggiungi disponibilità");
        disponibilitaButton.setBackground(new Color(255, 255, 255));
        disponibilitaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        disponibilitaButton.addActionListener(e -> aggiungiDisponibilitaPubblicazione());

        JButton indietroButton = new JButton("Indietro");
        indietroButton.setBackground(new Color(255, 255, 255));
        indietroButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        indietroButton.addActionListener(e -> tornaAdminPage());


        JPanel pannelloBottoni = new JPanel(new FlowLayout());
        pannelloBottoni.add(bottoneAggiungiPubblicazione);
        pannelloBottoni.add(bottoneEliminaPubblicazione);
        pannelloBottoni.add(disponibilitaButton);
        pannelloBottoni.add(indietroButton);


        frame.getContentPane().add(pannelloBottoni, BorderLayout.SOUTH);



    }

    /**
     * Chiude PubblicazioneGUI e rend visibile AdminPage
     */
    private void tornaAdminPage() {
        frame.dispose();

        adminPage.setVisible(true);
    }


    /**
     * Realizza il frame per l'inserimento della disponibilita della pubblicazione selezionata, presso un canale di distribuzione in una specifica< modalita' di fruizione (selezionabile tramite le  rispettive ComboBox)
     */
    private void aggiungiDisponibilitaPubblicazione() {
        JFrame f = new JFrame("Aggiungi Pubblicazione");
        f.setSize(400, 200);
        f.setLayout(new GridLayout(0, 2));
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setLocationRelativeTo(null);

        String pubblicazione = pubblicazioneList.getSelectedValue();

        if (pubblicazione != null) {
            f.setVisible(true);

            JLabel label = new JLabel("Seleziona il canale di distribuzione:");
            f.add(label);

            List<String> canaliList = controller.visualizzaCanali();
            ComboBoxModel<String> canaliComboBoxModel = new DefaultComboBoxModel<>(canaliList.toArray(new String[0]));

            JComboBox<String> canaliComboBox = new JComboBox<>(canaliComboBoxModel);
            f.add(canaliComboBox);

            Set<String> modalita = controller.getModalitaFruizionePubblicazione(pubblicazione);

            if (modalita != null) {

                JLabel labelModalita = new JLabel("Seleziona la modalità di fruizione:");
                f.add(labelModalita);

                JComboBox<String> modalitaFruizione = new JComboBox<>(modalita.toArray(new String[0]));
                f.add(modalitaFruizione);

                JButton confermaButton = new JButton("Conferma");
                confermaButton.setBackground(new Color(255, 255, 255));
                confermaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                confermaButton.addActionListener(e -> {
                    try {
                        String selectedCanale = (String) canaliComboBox.getSelectedItem();
                        String selectedModalita = (String) modalitaFruizione.getSelectedItem();

                        if (selectedCanale == null || selectedModalita == null) {
                            JOptionPane.showMessageDialog(f, "Seleziona un canale e una modalità di fruizione.");
                        }
                        else if(controller.verificaDisponibilitaPubblicazione(pubblicazione,  selectedCanale, selectedModalita)) {
                                JOptionPane.showMessageDialog(f, "Pubblicazione già disponibile presso "+ selectedCanale+ " nel formato selezionato: " + selectedModalita);
                        } else if (controller.aggiungiDisponibilitaPubblicazione(pubblicazione,  selectedCanale, selectedModalita))
                                    JOptionPane.showMessageDialog(f, "Disponibilità aggiunta con successo");
                                else
                                    JOptionPane.showMessageDialog(f, "Errore durante l'inserimento.");

                        f.dispose();
                    } catch (Exception ex) {
                        ex.printStackTrace(); // Print the exception for debugging
                        JOptionPane.showMessageDialog(f, "Errore generico durante l'operazione.");
                    }
                });
                f.add(confermaButton);
            } else {
                JOptionPane.showMessageDialog(f, "Errore: Modalità di fruizione non disponibili.");
                f.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(f, "Seleziona prima una pubblicazione.");
            f.dispose();
        }
    }



    /**
     * Realizza un frame e il form per l'inserimento di tutte le informazioni di una nuova pubblicazione.
     */
    private void gestisciAggiungiPubblicazione() {
        aggiungiPubblicazioneFrame = new JFrame("Aggiungi Pubblicazione");
        aggiungiPubblicazioneFrame.setSize(400, 400);
        aggiungiPubblicazioneFrame.setLayout(new GridLayout(0, 2));
        aggiungiPubblicazioneFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        aggiungiPubblicazioneFrame.setLocationRelativeTo(null);

        // Componenti per l'inserimento delle informazioni
        JLabel isbnLabel = new JLabel("ISBN:");
        JTextField isbnField = new JTextField();


        JLabel titoloLabel = new JLabel("Titolo:");
        JTextField titoloField = new JTextField();
        consentiSoloLettere(titoloField);


        JLabel editoreLabel = new JLabel("Editore:");
        JTextField editoreField = new JTextField();
        consentiSoloLettere(editoreField);

        JLabel conferenzaLabel = new JLabel("Conferenza:");
        Integer[] elencoConferenze = controller.getElencoConferenze().toArray(new Integer[0]);
        Integer[] elencoCompleto = new Integer[elencoConferenze.length + 1];
        System.arraycopy(elencoConferenze, 0, elencoCompleto, 1, elencoConferenze.length);
        elencoCompleto[0] = null; // Aggiungi un'opzione per "Nessuna serie"
        JComboBox<Integer> conferenzaComboBox = new JComboBox<>(elencoCompleto);



        JLabel rivistaLabel = new JLabel("Rivista:");
        String[] elencoRiviste = controller.getElencoRiviste().toArray(new String[0]);
        String[] elencoCompletoR = new String[elencoRiviste.length + 1];
        System.arraycopy(elencoRiviste, 0, elencoCompletoR, 1, elencoRiviste.length);
        elencoCompleto[0] = null; // Aggiungi un'opzione per "Nessuna serie"
        JComboBox<String> rivistaComboBox = new JComboBox<>(elencoCompletoR);



        JLabel annoPubbLabel = new JLabel("Anno Pubblicazione:");
        JTextField annoPubbField = new JTextField();
        consentiSoloNumeri(annoPubbField);


        JLabel modalitaFruizioneLabel = new JLabel("Modalità fruizione:");
        JPanel modalitaFruizionePanel = new JPanel(); // Pannello per contenere i radio button

        cartaceoCheckBox = new JCheckBox("Cartaceo");
        digitaleCheckBox = new JCheckBox("Digitale");
        audiolibroCheckBox = new JCheckBox("Audiolibro");

        // Aggiunta dei checkbox al pannello
        modalitaFruizionePanel.setLayout(new GridLayout(3, 1));
        modalitaFruizionePanel.add(cartaceoCheckBox);
        modalitaFruizionePanel.add(digitaleCheckBox);
        modalitaFruizionePanel.add(audiolibroCheckBox);

        JLabel autoreLabel = new JLabel("Autore:");
        JTextField autoreField = new JTextField();




        JButton confermaButton = new JButton("Conferma");
        confermaButton.setBackground(new Color(255, 255, 255));
        confermaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        confermaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aggiungiPubblicazione(isbnField.getText(), titoloField.getText(),
                        editoreField.getText(),
                        annoPubbField.getText(), conferenzaComboBox.getSelectedItem(), rivistaComboBox.getSelectedItem(),
                       autoreField.getText());
            }
        });



        aggiungiPubblicazioneFrame.add(isbnLabel);
        aggiungiPubblicazioneFrame.add(isbnField);

        aggiungiPubblicazioneFrame.add(titoloLabel);
        aggiungiPubblicazioneFrame.add(titoloField);

        aggiungiPubblicazioneFrame.add(editoreLabel);
        aggiungiPubblicazioneFrame.add(editoreField);


        aggiungiPubblicazioneFrame.add(annoPubbLabel);
        aggiungiPubblicazioneFrame.add(annoPubbField);

        aggiungiPubblicazioneFrame.add(rivistaLabel);
        aggiungiPubblicazioneFrame.add(rivistaComboBox);

        aggiungiPubblicazioneFrame.add(conferenzaLabel);
        aggiungiPubblicazioneFrame.add(conferenzaComboBox);

        aggiungiPubblicazioneFrame.add(modalitaFruizioneLabel);
        aggiungiPubblicazioneFrame.add(modalitaFruizionePanel);


        aggiungiPubblicazioneFrame.add(autoreLabel);
        aggiungiPubblicazioneFrame.add(autoreField);

        aggiungiPubblicazioneFrame.add(confermaButton);

        aggiungiPubblicazioneFrame.setVisible(true);
    }

    /**
     * Riceve in input tutte le informazione dell pubblicazione da inserire, effettua i controlli per controllare la validita' dei dati inseriti e conseguentemente richiama il metodo per inserire la pubblicazione nel DB.
     *
     * @param isbn       l'isbn
     * @param titolo     il titolo
     * @param editore    l'editore
     * @param annoPubb   l'anno di pubblicazione
     * @param conferenza la conferenza
     * @param rivista    la rivista
     * @param autore     il\gli autore
     */
    public void aggiungiPubblicazione(String isbn, String titolo, String editore, String annoPubb, Object conferenza , Object rivista, String autore) {
        if (isbn.isEmpty() || titolo.isEmpty() || editore.isEmpty() || annoPubb.isEmpty()) {
            JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Compila tutti i campi del form.");
        } else {
            if (conferenza == null && rivista == null) {
                JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame,"Devi inserire necessariamente una rivista o una conferenza");
            } else if (conferenza != null && rivista != null) {
                JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Devi inserire esclusivamente o una Conferenza o una Rivista");
            } else {
                if (!isValidISBN(isbn)) {
                    JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Formato ISBN non valido.");
                } else {
                    // Controllo unicita' ISBN e titolo
                    if (controller.cercaPubblicazione("isbn", isbn)) {
                        JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "L'ISBN inserito appartiene già ad un altra pubblicazione.");
                    } else if (controller.cercaPubblicazione("titolo", titolo)) {
                        JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Il titolo inserito appartiene già ad un'altra pubblicazione.");
                    } else {
                        // Controllo modalità di fruizione
                        Set<String> modalitaFruizioneSet = getModalitaFruizioneSelezionate();
                        if (modalitaFruizioneSet.isEmpty()) {
                            JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Seleziona almeno una modalità di fruizione.");
                        } else {
                            // Controllo autori
                            Set<String> autoreSet = new HashSet<>(Arrays.asList(autore.split("\\s*,\\s*")));
                            if (autore.length ()< 2) {
                                JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Inserisci almeno un autore");
                            } else {
                                // Chiamata al metodo di aggiunta del libro
                                if (controller.aggiungiPubblicazione(isbn, titolo, editore, annoPubb, String.valueOf((Integer) conferenza), (String) rivista, modalitaFruizioneSet, autoreSet)) {
                                    JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Pubblicazione aggiunta con successo.");
                                    aggiornaLista(controller.visualizzaPubblicazioni(), pubblicazioneListModel);
                                    aggiungiPubblicazioneFrame.dispose();
                                } else {
                                    JOptionPane.showMessageDialog(aggiungiPubblicazioneFrame, "Errore durante l'aggiunta della pubblicazione.");
                                }
                            }
                        }
                    }
                }
            }
        }
    }



    /**
     * Aggiunge ad un elenco tutte le modalita di fruizione selezionate per l'inserimento di un libro.
     *
     * @return  le modalita di fruizione che sono state selezionate
     */
    private Set<String> getModalitaFruizioneSelezionate() {
        Set<String> modalitaFruizioneSet = new HashSet<>();
        if (cartaceoCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Cartaceo");
        }
        if (digitaleCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Digitale");
        }
        if (audiolibroCheckBox.isSelected()) {
            modalitaFruizioneSet.add("Audiolibro");
        }
        return modalitaFruizioneSet;
    }

    /**
     * Preleva la pubblicazione selezionata e richiama il metodo per eliminarla, successivamente aggiorna la lista
     */
    private void gestisciEliminaPubblicazione() {
        // Ottieni il libro selezionato
        String pubblicazioneSelezionata = pubblicazioneList.getSelectedValue();
        if (pubblicazioneSelezionata != null) {
            // Chiamata al metodo per eliminare il libro
            controller.eliminaPubblicazione(pubblicazioneSelezionata);
            aggiornaLista(controller.visualizzaPubblicazioni(), pubblicazioneListModel);
        } else {
            JOptionPane.showMessageDialog(frame, "Seleziona una pubblicazione da eliminare.");
        }
    }

    /**
     * Consente di inserire solamente lettere
     */
    private void consentiSoloLettere(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("[a-zA-Z ]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    /**
     * Controlla se il formato dell'isbn dato in input e' corretto.
     *
     * @param isbn tl'isbn
     * @return vero se il formato e' corretto, falso altrimenti
     */
    public  boolean isValidISBN(String isbn) {
        // Espressione regolare per ISBN-13
        String regex = "^(97[89])?\\d{9}(\\d|X)$";

        // Crea un oggetto Pattern
        Pattern pattern = Pattern.compile(regex);

        // Crea un oggetto Matcher con l'ISBN fornito
        Matcher matcher = pattern.matcher(isbn);

        // Verifica se c'è una corrispondenza
        return matcher.matches();
    }

    /**
     * Consente di inserire soltanto numeri
     */
    private void consentiSoloNumeri(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

}














