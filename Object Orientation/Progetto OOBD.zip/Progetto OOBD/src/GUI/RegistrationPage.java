package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * La GUI RegistrationPage.
 */
public class RegistrationPage extends JFrame {
    private JTextField matricolaField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField nomeField;
    private JTextField cognomeField;
    private JTextField usernameField;

    private Controller controller;
    private JFrame loginPage;

    /**
     * Costruttore della classe. Realizza il form per l'inserimento delle informazioni del nuovo utente.
     *
     * @param controller il controller
     * @param loginPage  loginPage
     */
    public RegistrationPage(Controller controller, JFrame loginPage) {
        super("Registration Page");

        this.controller = controller;
        this.loginPage = loginPage;

        // Creazione dei componenti
        JLabel matricolaLabel = new JLabel("Matricola:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel confirmPasswordLabel = new JLabel("Conferma Password:");
        JLabel nomeLabel = new JLabel("Nome:");
        JLabel cognomeLabel = new JLabel("Cognome:");
        JLabel usernameLabel = new JLabel("Username:");

        matricolaField = new JTextField(20);
        consentiSoloNumeri(matricolaField);

        passwordField = new JPasswordField(20);
        confirmPasswordField = new JPasswordField(20);

        usernameField = new JTextField(20);
        consentiSoloLettereNumeriUnderscore(usernameField);

        nomeField = new JTextField(20);
        consentiSoloLettere(nomeField);

        cognomeField = new JTextField(20);
        consentiSoloLettere(cognomeField);

        JButton registrazioneButton = new JButton("Registrati");
        registrazioneButton.setBackground(new Color(255, 255, 255));
        registrazioneButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registrazioneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        JButton tornaAllaPaginaDiLoginButton = new JButton("Torna alla pagina di login");
        tornaAllaPaginaDiLoginButton.setBackground(new Color(255, 255, 255));
        tornaAllaPaginaDiLoginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        tornaAllaPaginaDiLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tornaAllaPaginaLogin();
            }
        });

        // Creazione del layout
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);  // Margini per tutti gli elementi

        // Aggiunta dei componenti al layout
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(matricolaLabel, gbc);

        gbc.gridx = 1;
        add(matricolaField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(passwordLabel, gbc);

        gbc.gridx = 1;
        add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(confirmPasswordLabel, gbc);

        gbc.gridx = 1;
        add(confirmPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(nomeLabel, gbc);

        gbc.gridx = 1;
        add(nomeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(cognomeLabel, gbc);

        gbc.gridx = 1;
        add(cognomeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(usernameLabel, gbc);

        gbc.gridx = 1;
        add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;  // Unisci due colonne per il pulsante di registrazione
        add(registrazioneButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;  // Unisci due colonne per il pulsante di torna alla pagina di login
        add(tornaAllaPaginaDiLoginButton, gbc);

        // Impostazioni JFrame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    /**
     * Consente di inserire solamente numeri
     */
    private void consentiSoloNumeri(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    /**
     * Consente di inserire solamente lettere
     */
    private void consentiSoloLettere(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("[a-zA-Z]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    /**
     * Consente di inserire solamente lettere numeri e il carattere '_'
     */
    private void consentiSoloLettereNumeriUnderscore(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text.matches("[a-zA-Z0-9_]*")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }



    /**
     * Chiude RegistrationPage e apre LoginPage
     */
    private void tornaAllaPaginaLogin() {
        loginPage.setVisible(true);
        this.setVisible(false);
        this.dispose();
    }


    /**
     * Verifica la validita dei dati inseriti, conseguentemente chiama il metodo per l'inserimento del nuovo utente all'interno del DB, chiude RegistrationPage e ritorna alla LoginPage
     */

    private void register() {

        int matricola;
        String matricolaText = matricolaField.getText().trim();  // Rimuove gli spazi bianchi
        if (matricolaText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Inserisci una matricola valida.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            matricola = Integer.parseInt(matricolaText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Inserisci una matricola valida.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String password = new String(passwordField.getPassword());
        String confermaPassword = new String(confirmPasswordField.getPassword()); // Ottenere la conferma della password
        String nome = nomeField.getText();
        String cognome = cognomeField.getText();
        String username = usernameField.getText();

        // Validazione dei campi
        if (matricolaField.getText().isEmpty() || password.isEmpty() || confermaPassword.isEmpty() || nome.isEmpty() || cognome.isEmpty() || username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa tutti i campi.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return; // Esce dal metodo se un campo è vuoto
        }

        // Verifica se la matricola esiste già (da implementare con la tua logica specifica)
        if (controller.verificaEsistenzaUtente(matricola)) {
            JOptionPane.showMessageDialog(this, "Utente con la stessa matricola già esistente.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return; // Esce dal metodo se la matricola esiste già
        }

        if (controller.verificaEsistenzaUsername(username)) {
            JOptionPane.showMessageDialog(this, "Questo Username e' utilizzato gia da un altro utente.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verifica se le due password coincidono
        if (!password.equals(confermaPassword)) {
            JOptionPane.showMessageDialog(this, "Le password non coincidono.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return; // Esce dal metodo se le password non coincidono
        }

        // Verifica dei criteri della password
        if (!checkCriteriPassword(password)) {
            JOptionPane.showMessageDialog(this, "La password deve essere almeno di 10 caratteri, deve contenere almeno una cifra, una lettera minuscola e una maiuscola.", "Errore di registrazione", JOptionPane.ERROR_MESSAGE);
            return; // Esce dal metodo se la password non rispetta i criteri
        }

        if (controller.effettuaRegistrazione(matricola, password, nome, cognome, username)) {
            // Mostra un messaggio di registrazione riuscita
            JOptionPane.showMessageDialog(this, "Registrazione riuscita!");



            loginPage.setVisible(true);
            this.setVisible(false);
            this.dispose();
        }
    }

    /**
     * Verifica che la password inserita rispetti i criteri desiderati
     *
     * @param password la password inserita
     *
     * @return vero se la password inserita rispetta i criteri, falso altrimenti
     */
    private boolean checkCriteriPassword(String password) {
        // Verifica i criteri della password
        return password.length() >= 10 &&
                password.matches(".*[0-9].*") &&   // Contiene almeno una cifra
                password.matches(".*[a-z].*") &&   // Contiene almeno una lettera minuscola
                password.matches(".*[A-Z].*");     // Contiene almeno una lettera maiuscola
    }
}