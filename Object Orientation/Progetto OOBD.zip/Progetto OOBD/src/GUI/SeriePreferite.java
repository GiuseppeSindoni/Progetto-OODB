package GUI;

import Controller.Controller;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

/**
 * La GUI SeriePreferite.
 */
public class SeriePreferite extends JFrame {

    private Controller controller;
    private int matricola;
    private JList<String> serieList;

    /**
     * Il costruttore della classe, realizza la lista delle serie preferite dell'utente e realizza i comportamenti per eliminare o aggiungere una serie.
     *
     * @param controller il controller
     * @param jFrame     la GUI che ha instanziarto SeriePreferite
     * @param matricola  la matricola dell'utente che attualmente ha effettuato il login
     */
    public SeriePreferite(Controller controller, JFrame jFrame, int matricola) {
        this.controller = controller;
        this.matricola = matricola;

        DefaultListModel<String> serieListModel = new DefaultListModel<>();
        serieList = new JList<>(serieListModel);

        serieList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                    String serie = (String) value;
                    setText(serie);

                return this;
            }
        });

        serieList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON3) { // Controllo del tasto destro
                    String selectedSerie = serieList.getSelectedValue();
                    if (selectedSerie != null) {
                        mostraMenuContestuale(e.getComponent(), e.getX(), e.getY(), selectedSerie);
                    }
                }
            }
        });

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                modificaListaSeriePreferite();
            }
        });

        List<String> elencoSerie = controller.SeriePreferite(matricola);
        for (String serie : elencoSerie) {
            serieListModel.addElement(serie);
        }

        setTitle("Preferiti");
        setLayout(new BorderLayout());
        add(new JScrollPane(serieList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new BorderLayout());

        JButton aggiungiButton = new JButton("Aggiungi Serie ai preferiti");
        aggiungiButton.setBackground(new Color(255, 255, 255));
        aggiungiButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        aggiungiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                apriAggiungiSerie();
            }
        });
        buttonPanel.add(aggiungiButton, BorderLayout.NORTH);

        JButton eliminaButton = new JButton("Elimina Serie dai preferiti");
        eliminaButton.setBackground(new Color(255, 255, 255));
        eliminaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        eliminaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminaSeriePreferita(serieList.getSelectedValue());
            }
        });
        buttonPanel.add(eliminaButton, BorderLayout.SOUTH);


        add(buttonPanel, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    /**
     * Istanza la GUI AggiungiSerie e la visualizza
     */
    private void apriAggiungiSerie() {
        AggiungiSerie aggiungiSerie = new AggiungiSerie(controller, this, matricola);
        aggiungiSerie.setVisible(true);
    }

    /**
     * Elimina la serie che e' stata selezionata e successivamente riaggiorna la lista
     *
     * @param serieSelezionata serie da eliminare
     */
    private void eliminaSeriePreferita(String serieSelezionata) {
        if (serieSelezionata != null) {
            controller.eliminaSeriePreferita(matricola, serieSelezionata);
            modificaListaSeriePreferite();
        } else {
            JOptionPane.showMessageDialog(this, "Seleziona una serie dalla lista.", "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Aggiorna la lista delle serie preferite.
     */
    public void modificaListaSeriePreferite() {
        List<String> elencoSerie = controller.SeriePreferite(matricola);
        DefaultListModel<String> serieListModel = (DefaultListModel<String>) serieList.getModel();
        serieListModel.removeAllElements();

        for (String serie : elencoSerie) {
            serieListModel.addElement(serie);
        }
    }

    /**
     * Visualizza i libri della serie data in input
     */
    private void visualizzaLibriDellaSerie(String serie) {
        List<String> libriSerie = controller.getLibriSerie(serie);

        JFrame libriDellaSerieFrame = new JFrame("Libri della Serie: " + serie);
        libriDellaSerieFrame.setLayout(new BorderLayout());

        DefaultListModel<String> libriListModel = new DefaultListModel<>();
        JList<String> libriList = new JList<>(libriListModel);

        for (String libro : libriSerie) {
            libriListModel.addElement(libro);
        }

        libriList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                String libro = (String) value;
                setText(libro);

                return this;
            }
        });

        libriList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String selectedLibro =  libriList.getSelectedValue();
                    if (selectedLibro != null) {
                        new DettagliFrame(controller, "Libro", selectedLibro);
                    }
                }
            }
        });

        libriDellaSerieFrame.add(new JScrollPane(libriList), BorderLayout.CENTER);

        libriDellaSerieFrame.setSize(400, 300);
        libriDellaSerieFrame.setLocationRelativeTo(SeriePreferite.this);
        libriDellaSerieFrame.setVisible(true);
    }





    private void mostraMenuContestuale(Component component, int x, int y, String selectedSerie) {
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem visualizzaLibriItem = new JMenuItem("Visualizza Libri");
        visualizzaLibriItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                visualizzaLibriDellaSerie(selectedSerie);
            }
        });



        popupMenu.add(visualizzaLibriItem);


        popupMenu.show(component, x, y);
    }
}