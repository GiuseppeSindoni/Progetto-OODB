package implementazionePostgresDAO;

import ConnessionDatabase.ConnessioneDatabase;
import DAO.CanaleDistribuzioneDAO;
import model.*;

import javax.swing.*;
import java.sql.*;
import java.time.LocalTime;
import java.util.*;

/**
 * La classe Canale distribuzione DAOImpl che implementa l'interfaccia CanaleDistribuzioneDAO.
 */
public class CanaleDistribuzioneDAOImpl implements CanaleDistribuzioneDAO {
    private Connection connection;

    /**
     * Costruttore della classe, ottiene un'istanza della connessione
     */
    public CanaleDistribuzioneDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Trova i canali distribuzione che dispongono per intero di almeno una serie preferita dell'utente.
     *
     * @param utente l'utente di interesse
     * @return una lista di liste di stringhe (lista di (nome Canale, nome Serie di cui dispone))
     */
    //QUERY GRUPPO DA 3
    public List<List<String>>  trovaCanaliDistribuzioneSerie (int utente) {
        List<List<String>> risultati = new ArrayList<>();

        try {
            String query = "SELECT * FROM trova_Librerie_Siti(?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, utente);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {

                        String nomeCanale = resultSet.getString("nome_canale");
                        String nomeSerie = resultSet.getString("nome_Serie");

                        List<String> risultati1 = new ArrayList<>();
                        risultati1.add(nomeCanale); risultati1.add(nomeSerie);

                        risultati.add(risultati1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;
    }
    /**
     * Visualizza il nome di tutti i canali presenti ne DB.
     *
     * @returnla lista dei nomi di tutti i canali
     */
    public List<String> visualizzaCanali () {
        List<String> canali = new ArrayList<>();
        try {
            String query = "SELECT c.nome as nomecanale from canaledistribuzione as c";

            try(PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String canaleDistribuzione = resultSet.getString("nomecanale");
                        canali.add(canaleDistribuzione);
                    }
                }


            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return canali;
    }

    /**
     * Istanzia un oggetto CanaleDistribuzione, ottenendo tutte le informazioni ds un resulSet
     *
     * @param resultSet il resultSet da cui prendere tutte le informazione
     * @return un riferimento ad un oggetto CanaleDistribuzione
     */
    private CanaleDistribuzione costruisciCanaleDaResultSet(ResultSet resultSet) throws SQLException {
        int codCanale = resultSet.getInt("codcanale");
        String nome = resultSet.getString("nome");
        String tipoCanale = resultSet.getString("tipocanale");

        CanaleDistribuzione c = null;

        switch (tipoCanale) {
            case "Sito Online":
                String url = resultSet.getString("url");
                c =  new CanaleDistribuzione(codCanale, nome, tipoCanale, url);
            case "Libreria":
                String indirizzo = resultSet.getString("indirizzo");
                String numeroTelefono = resultSet.getString("numerotelefono");
                Time orarioAperturaTime = resultSet.getTime("orarioapertura");
                Time orarioChiusuraTime = resultSet.getTime("orariochiusura");

                LocalTime orarioApertura = (orarioAperturaTime != null) ? orarioAperturaTime.toLocalTime() : null;
                LocalTime orarioChiusura = (orarioChiusuraTime != null) ? orarioChiusuraTime.toLocalTime() : null;

                c = new CanaleDistribuzione(codCanale, nome, tipoCanale, indirizzo, numeroTelefono, orarioApertura, orarioChiusura);



        }

        return c;
    }
    /**
     * Trova un canale distrbuzione grazie al nome.
     *
     * @param nome il nome del canale
     * @return un riferimento a null, se il canale non viene trovato, o un riferimento ad un oggetto CanaleDistribuzione
     */
    public CanaleDistribuzione trovaCanaleDistribuzione(String nome) {
        CanaleDistribuzione canale = null;

        try {
            String query = "SELECT * FROM canaledistribuzione WHERE nome LIKE ? ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + nome + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        canale = costruisciCanaleDaResultSet(resultSet);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return canale;
    }


    /**
     * Ricerca tutti i canali dove è disponibile uno specifico libro.
     *
     * @param libro il libro d'interesse
     * @return un hashmap(nome Canale, modalità di fruizione per cui quel libro è disponbile presso quel canale)
     */
    public Map<String, Set<String>> disponibilita(Libro libro) {
        Map<String, Set<String>> result = new HashMap<>();

        try {
            String query = "SELECT c.nome as nomecanale, dl.modalitafruizione as modalitafruizione " +
                    "FROM (libro l JOIN disponibilital dl ON l.ISBN = dl.ISBN) " +
                    "JOIN canaledistribuzione c ON c.codCanale = dl.canale " +
                    "WHERE l.ISBN like ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + libro.getISBN() + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String canaleDistribuzione = resultSet.getString("nomecanale");
                        String modF = resultSet.getString("modalitafruizione");

                        // Verifica se la chiave (nome del canale di distribuzione) esiste già nell'HashMap
                        if (result.containsKey(canaleDistribuzione)) {
                            // Se la chiave esiste già, ottieni la lista corrispondente e aggiungi la nuova modalità
                            result.get(canaleDistribuzione).add(modF);
                        } else {
                            // Se la chiave non esiste ancora, crea una nuova lista e inseriscila nell'HashMap
                            Set<String> modalitaList = new HashSet<>();
                            modalitaList.add(modF);
                            result.put(canaleDistribuzione, modalitaList);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }



    /**
     * Ricerca tutti i canali dove è disponibile uno specifico libro.
     *
     * @param pubblicazione la pubblicazione d'interesse
     * @return un hashmap(nome Canale, modalità di fruizione per cui quella pubblicazione è disponibile presso quel canale)
     */
    // retsituisce i canali presso i quali e' disponibile una specifica pubblicazione
    public Map<String, Set<String>> disponibilita(Pubblicazione pubblicazione) {
        Map<String, Set<String>> result = new HashMap<>();

        try {
            String query = "SELECT c.nome as nomecanale, dp.modalitafruizione as modalitafruizione " +
                    "FROM (pubblicazione p JOIN disponibilitap dp ON p.ISBN = dp.ISBN) " +
                    "JOIN canaledistribuzione c ON c.codCanale = dp.canale " +
                    "WHERE p.ISBN like ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + pubblicazione.getISBN() + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String canaleDistribuzione = resultSet.getString("nomecanale");
                        String modF = resultSet.getString("modalitafruizione");

                        // Verifica se la chiave (nome del canale di distribuzione) esiste già nell'HashMap
                        if (result.containsKey(canaleDistribuzione)) {
                            // Se la chiave esiste già, ottieni la lista corrispondente e aggiungi la nuova modalità
                            result.get(canaleDistribuzione).add(modF);
                        } else {
                            // Se la chiave non esiste ancora, crea una nuova lista e inseriscila nell'HashMap
                            Set<String> modalitaList = new HashSet<>();
                            modalitaList.add(modF);
                            result.put(canaleDistribuzione, modalitaList);
                        }
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }



}

