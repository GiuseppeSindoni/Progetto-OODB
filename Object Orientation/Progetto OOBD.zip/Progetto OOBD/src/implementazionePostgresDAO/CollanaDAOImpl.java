package implementazionePostgresDAO;


import model.Collana;
import DAO.CollanaDAO;
import ConnessionDatabase.ConnessioneDatabase;
import model.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * La classe CollanaDAOImpl che implementa l'interfaccia CollanaDAO.
 */
public class CollanaDAOImpl implements CollanaDAO {

    private Connection connection;


    /**
     * Costruttore della classe, che ottiene un istanza della connessione.
     */
    public CollanaDAOImpl () {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Seleziona le collane a cui appartono almeno un libro.
     *
     * @return  Una lista di liste di stringhe (nome collana- editore)
     */
    public List<List<String>> getCollane () {
        List<List<String>> risultati = new ArrayList<>();

        try {
            String query = "SELECT distinct c.nome as collnome, c.editore as colleditore FROM collana c INNER JOIN compone co ON c.codcollana = co.collana; ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        List<String > lista = new ArrayList<>();
                        lista.add(resultSet.getString("collnome"));
                        lista.add(resultSet.getString("colleditore"));

                        risultati.add(lista);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;

    }

    /**
     * cerca una collana secondo il nome
     *
     * @param nomeCollana il nome della collana
     * @return un riferimento ad un ogetto Collana
     */
    public Collana trovaCollana(String nomeCollana) {
        Collana collana = null;

        try {
            String query = "SELECT * FROM collana WHERE nome = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, nomeCollana);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int codCollana = resultSet.getInt("codcollana");
                        String nome = resultSet.getString("nome");
                        String editore = resultSet.getString("editore");
                        String criterio = resultSet.getString("criterio");

                        collana = new Collana(codCollana, nome, editore, criterio);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return collana;
    }


}
