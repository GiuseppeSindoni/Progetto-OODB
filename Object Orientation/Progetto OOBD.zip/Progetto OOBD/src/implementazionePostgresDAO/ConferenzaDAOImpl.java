package implementazionePostgresDAO;

import DAO.ConferenzaDAO;

import ConnessionDatabase.ConnessioneDatabase;
import model.Conferenza;
import model.Serie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * La classe ConferenzaDAOImpl che implementa l'interfaccia ConferenzaDAO.
 */
public class ConferenzaDAOImpl implements ConferenzaDAO {

    private Connection connection;

    /**
     * Costruttore della classe COnferenzaDAOImpl, ottiene un'istaza della connessione al DB
     */
    public ConferenzaDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Recupera una conferenza ricercandola tramite il suo codice identificativo.
     *
     * @param idConferenza il codice della conferenza
     * @return un riferimento a null (se la conferenza non e' stata trovata), o un riferimento ad un oggetto Conferenza
     */
    public Conferenza recuperaConferenzaDaDatabase(int idConferenza) {
        Conferenza conferenza = null;

        try {
            String query = "SELECT * FROM conferenza WHERE codconferenza = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, idConferenza);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {

                        conferenza = new Conferenza(
                                resultSet.getInt("codconferenza"),
                                resultSet.getString("nome"),
                                resultSet.getDate("datainizio"),
                                resultSet.getDate("datafine"),
                                resultSet.getString("luogo"),
                                resultSet.getString("responsabile"),
                                resultSet.getString("strutturaorganizzatrice")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return conferenza;
    }


    /**
     * Recupera i codici di tutte le conferenze presenti nel DB.
     *
     * @return una lista di interi contente il codice di tutte le conferenze
     */
    public List<Integer> getElencoConferenze() {
        List<Integer> elencoConferenze = new ArrayList<>();

        try {
            String query = "SELECT codconferenza FROM conferenza";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Integer n = resultSet.getInt("codconferenza");
                    elencoConferenze.add(n);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elencoConferenze;
    }

}
