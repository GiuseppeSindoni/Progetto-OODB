package implementazionePostgresDAO;

import ConnessionDatabase.ConnessioneDatabase;
import DAO.*;
import model.*;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * La classe LibroDAOImpl che implementa l'interfaccia LibroDAO.
 */
public class LibroDAOImpl implements LibroDAO {
    private Connection connection;

    /**
     * Costruttore della classe, che ottiene un'istanza della connessione.
     */
    public LibroDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Aggiunge la disponibilita' di un libro presso uno specifico canale, in una specifica modalita' di fruizione.
     *
     * @param libro il libro d'interesse
     * @param canale il canale presso cui sara' disponibilie il libro
     * @param modalita la modalita' di fruizione
     * @return vero se l'inserimento è avvenuto correttamente, falso altrimenti
     */
    public boolean aggiungiDisponibilita (String libro, int canale, String modalita) {
            String query = "INSERT INTO disponibilital(isbn, canale, modalitafruizione) VALUES (?, ?, ?)";

            try {
                try(PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    preparedStatement.setString(1, libro);
                    preparedStatement.setInt(2,canale);
                    preparedStatement.setString(3, modalita);

                    int rowsAffected = preparedStatement.executeUpdate();
                    return rowsAffected > 0;
                }


            } catch (SQLException e) {
                e.printStackTrace();
            }
        return false;
    }

    /**
     * Effettua una ricerca sui libri, filtrandola secondo il valore di uno specifico campo.
     *
     * @param campo l'attributo
     * @param searchString il valore dell'attributo
     * @return un elenco di libri che soddisfano i criteri della ricerca
     */
    public List<Libro> cercaLibro(String campo, String searchString) {
        List<Libro> risultati = new ArrayList<>();

        try {
            String query = "SELECT * FROM libro WHERE " + campo + " LIKE ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + searchString + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Libro libro = costruisciLibroDaResultSet(resultSet);
                        risultati.add(libro);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;
    }

    /**
     * Istanzia un oggetto libro, prendendo le informazioni da un resultSet
     *
     * @param resultSet il resultSet
     * @return un riferimento ad un oggetto Libro
     */
    private Libro costruisciLibroDaResultSet(ResultSet resultSet) throws SQLException {
        String ISBN = resultSet.getString("ISBN");
        String titolo = resultSet.getString("titolo");
        String editore = resultSet.getString("editore");
        Date dataUscita = resultSet.getDate("datauscita");
        String sala = resultSet.getString("salapresentazione");
        String tipo = resultSet.getString("tipo");
        int annoPubblicazione = resultSet.getInt("annopubblicazione");
        Set<String> modalitaFruizione = recuperaModalitaFruizioneDaDatabase(resultSet.getString("modalitafruizione"));


        // Utilizza il metodo per ottenere un Set di autori
        Set<String> autori = recuperaAutoriDaDatabase(resultSet.getString("autore"));

        Libro libro = null;
        if ("Romanzo".equals(tipo)) {
            int codSerie = resultSet.getInt("serie");


            SerieDAO serieDAO = new SerieDAOImpl();
            Serie serie = serieDAO.cercaSerieCod(codSerie);



            libro =  new Libro(ISBN, titolo, editore, dataUscita, sala, tipo,  annoPubblicazione,  autori,  serie);
            libro.setModalitaFruizione(modalitaFruizione);



        } else if ("Didattico".equals(tipo)) {
            libro =  new Libro(ISBN, titolo, editore, dataUscita, sala, tipo, annoPubblicazione, autori, null);
            libro.setModalitaFruizione(modalitaFruizione);

        }


        return libro;
    }

    /**
     * Trasforma una stringa di autori separati da virgola, in un elenco di autori.
     *
     * @param autori la stringa di autori
     * @return un elenco di autori
     */
    private Set<String> recuperaAutoriDaDatabase(String autori) {
        return new HashSet<>(Arrays.asList(autori.split("\\s*,\\s*")));
    }




    /**
     * Ricerca tutti i libri appartenenti ad una specifica serie.
     *
     * @param serie il codice della serie di interesse
     * @return l'elenco di titoli di tutti i libri appartenenti alla serie
     */
    public List<String> getLibriSerie(int serie) {
        List<String> libri = new ArrayList<>();

        try {
            String query = "SELECT l.titolo as tit FROM libro l WHERE serie = ? ORDER BY l.datauscita";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, serie);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String libro = resultSet.getString("tit");
                        libri.add(libro);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libri;
    }
    /**
     * Ricerca tutti i libri appartenenti ad una collana.
     *
     * @param collana il codice della collana di interesse
     * @return un elenco dei titoli di tutti i libri appartenenti alla collanaS
     */
    public List<String> getLibriCollana(int collana) {
        List<String> risultati = new ArrayList<>();

        try {
            String query = "SELECT l.titolo as tit FROM libro l INNER JOIN compone c ON l.isbn = c.isbn INNER JOIN collana coll ON c.collana = coll.codcollana WHERE coll.codcollana = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, collana);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String libro = resultSet.getString("tit");
                        risultati.add(libro);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;
    }



    /**
     * Ricerca il titolo di tutti i libri presenti nel DB.
     *
     * @return un elenco dei titoli di tutti i libri presenti nel database
     */
    public List<String> visualizzaLibri() {
        List<String> libri = new ArrayList<>();

        try {
            String query = "SELECT titolo FROM libro ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        libri.add(resultSet.getString("titolo"));
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libri;
    }


    /**
     * Trasforma una stringa di modalita di fruizione separate da virgola, in un elenco di modalita di fruizione.
     *
     * @param modalitaFruizione la stringa di modalita
     * @return un elenco delle modalita
     */
    private Set<String> recuperaModalitaFruizioneDaDatabase(String modalitaFruizione) {
        return new HashSet<>(Arrays.asList(modalitaFruizione.split("\\s*,\\s*")));
    }
    /**
     * Elimina un libro dal DB.
     *
     * @param titolo il titolo del libro da eliminare
     * @return vero se l'eliminazione e' avvenuta correttamente falso altrimenti
     */
    public boolean eliminaLibro (String titolo) {
        String query = "DELETE  FROM libro WHERE titolo like ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, "%" + titolo + "%");

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Inserisce un nuovo libro all'interno del DB.
     *
     * @param libro il libro da inserire
     * @return vero se l'inserimento e' avvenuto correttamente falso altrimenti.
     */
    public boolean inserisciLibro(Libro libro) {
        String query = "INSERT INTO libro(isbn, titolo, tipo, editore, salapresentazione, datauscita, annopubblicazione, modalitafruizione, serie, autore) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, libro.getISBN());
            preparedStatement.setString(2, libro.getTitolo());
            preparedStatement.setString(3, libro.getTipo());
            preparedStatement.setString(4, libro.getEditore());
            preparedStatement.setString(5, libro.getSala());
            preparedStatement.setDate(6, new java.sql.Date(libro.getDataUscita().getTime()));
            preparedStatement.setInt(7, libro.getAnnoPubblicazione());

            // Converte la modalità di fruizione in una stringa separata da virgole
            String modalitaFruizioneString = String.join(", ", libro.getModalitaFruizione());
            preparedStatement.setString(8, modalitaFruizioneString);

            if(libro.getSerie() != null)
                preparedStatement.setInt(9, libro.getSerie().getCodSerie());
            else preparedStatement.setNull(9, java.sql.Types.INTEGER);

            // Converte gli autori in una stringa separata da virgole
            String autoriString = String.join(", ", libro.getAutori());
            preparedStatement.setString(10, autoriString);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
