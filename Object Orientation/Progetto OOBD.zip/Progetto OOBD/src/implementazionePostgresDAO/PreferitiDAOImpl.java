package implementazionePostgresDAO;

import ConnessionDatabase.ConnessioneDatabase;
import DAO.PreferitiDAO;
import DAO.SerieDAO;
import model.Serie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * La classe PreferitiDAOImpl che implementa l'interfaccia PreferitiDAO.
 */
public class PreferitiDAOImpl implements PreferitiDAO {

    private Connection connection;


    /**
     * Costruttore della classe, ottiene un'istanza della connessione.
     */
    public PreferitiDAOImpl() {
        try {
            this.connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * Preleva le serie preferite di uno specifico utente.
     *
     * @param matricola la matricola dell'utente
     * @return un elenco di nomi delle serie preferite dell'utente
     */
    public List<String> SeriePreferite(int matricola) {
        List<String> elencoSerie = new ArrayList<>();

        try {
            String query = "SELECT nome FROM serie WHERE codserie IN (SELECT serie FROM preferiti WHERE utente = ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, matricola);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                      String serie =  resultSet.getString("nome");


                        elencoSerie.add(serie);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elencoSerie;
    }

    /**
     * Aggiunge ua serie ai preferiti di un utente.
     *
     * @param matricola la matricola dell'utente
     * @param  serie la serie da aggiungere ai preferiti
     * @return vero se l'inserimento e' andato a buon fine falso altrimenti
     */
    public boolean aggiungiSeriePreferita(int matricola, int serie) {

        String query = "INSERT INTO preferiti (utente, serie) VALUES (?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, matricola);
            preparedStatement.setInt(2, serie);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;  // Restituisce true se almeno una riga è stata inserita
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }

    }


    /**
     * Elimina una serie dell'elenco di preferiti di un utente
     *
     * @param matricola la matricola dell'utente
     * @param serie la serie da eliminare dall'elenco
     * @return
     */
    public boolean eliminaSeriePreferita(int matricola, int serie) {
        String query = "DELETE FROM preferiti WHERE utente = ? AND serie = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, matricola);
            preparedStatement.setInt(2, serie);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;  // Restituisce true se almeno una riga è stata inserita
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }
    }

    /**
     * Verifica se una serie fa gia' parte dei preferiti di un utente
     *
     * @param matricola il codice dell'utente
     * @param  serie la serie da ricercare
     * @return vero se la serie fa gia' parte dei preferiti, falso altrimenti
     */
    public boolean serieGiaPreferita(int matricola, int serie) {
        String query = "SELECT count(*) as numero FROM preferiti WHERE utente = ? and serie = ?";
        int count = 0;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, matricola);
            preparedStatement.setInt(2, serie);

            try(ResultSet rs = preparedStatement.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt("numero");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }

        return count > 0;
    }


}