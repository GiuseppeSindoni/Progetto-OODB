package implementazionePostgresDAO;

import ConnessionDatabase.ConnessioneDatabase;
import DAO.PubblicazioneDAO;
import model.Pubblicazione;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import model.*;

/**
 * La classe PubblicazioneDAOImpl che implementa l'interfaccia PubblicazioneDAO.
 */
public class PubblicazioneDAOImpl implements PubblicazioneDAO {
    private Connection connection;

    /**
     * Costruttore della classe che ottiene un'istanza della connessione.
     */
    public PubblicazioneDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Elimina una pubbliazione dal DB.
     *
     * @param titolo il titolo della pubblicazione da eliminare
     * @return vero se l'elimazione e' avvenuta con successo, falso altrimenti
     */
    public boolean eliminaPubblicazione (String titolo) {
        String query = "DELETE FROM pubblicazione WHERE titolo like ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, "%" + titolo + "%");

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;  // Restituisce true se almeno una riga è stata inserita
        } catch (SQLException e) {
            e.printStackTrace();

        }

        return false;
    }

    /**
     * Effettua una ricerca sulle pubblicazioni, filtrandola secondo il valore di uno specifico campo
     *
     * @param campo il campo
     * @param searchString il valore del campo
     * @return  la lista di pubblicazioni che soddisfano i criteri della ricerca
     */
    public List<Pubblicazione> cercaPubblicazioni(String campo, String searchString) {
        List<Pubblicazione> risultati = new ArrayList<>();

        try {
            String query = "SELECT * FROM pubblicazione WHERE " + campo +  " LIKE ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + searchString + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Pubblicazione pubblicazione = costruisciPubblicazioneDaResultSet(resultSet);
                        risultati.add(pubblicazione);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;
    }

    /**
     * Ricerca tutte le pubblicazione sul DB, selezionandone i titoli
     *
     * @return un elenco dei titoli di tutte le pubblicazioni
     */
    public List<String> visualizzaPubblicazioni() {
        List<String> risultati = new ArrayList<>();

        try {
            String query = "SELECT p.titolo as tit FROM pubblicazione as p";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    String pubblicazione = resultSet.getString("tit");
                    risultati.add(pubblicazione);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Puoi gestire l'eccezione in modo diverso a seconda delle tue esigenze
        }

        return risultati;
    }

    /**
     * Istanzia un oggetto pubblicazione, recuperando le informazioni da un resultSet
     *
     * @param resultSet il resultSet
     * @return un riferimento ad un oggetto Pubblicazione
     */
    private Pubblicazione costruisciPubblicazioneDaResultSet(ResultSet resultSet) throws SQLException {
        int idConferenza = resultSet.getInt("conferenza");
        String rivistaDOI = resultSet.getString("rivista");

        Pubblicazione pubblicazione = null;

        if (idConferenza != 0) {
            Conferenza conferenza = new ConferenzaDAOImpl().recuperaConferenzaDaDatabase(idConferenza);
            pubblicazione = new Pubblicazione(
                    resultSet.getString("ISBN"),
                    resultSet.getString("titolo"),
                    resultSet.getString("editore"),
                    resultSet.getInt("annopubblicazione"),
                    recuperaAutoriDaDatabase(resultSet.getString("autore")), // Aggiunto il recupero degli autori
                    conferenza
            );
        } else if (rivistaDOI != null) {
            Rivista rivista = new RivistaDAOImpl().recuperaRivistaDaDatabase(rivistaDOI);
            pubblicazione = new Pubblicazione(
                    resultSet.getString("ISBN"),
                    resultSet.getString("titolo"),
                    resultSet.getString("editore"),
                    resultSet.getInt("annopubblicazione"),
                    recuperaAutoriDaDatabase(resultSet.getString("autore")),
                    rivista
            );
        }


        Set<String> modalitaFruizione = recuperaModalitaFruizioneDaDatabase(resultSet.getString("modalitafruizione"));
        pubblicazione.setModalitaFruizione(modalitaFruizione);

        return pubblicazione;
    }




    //restituisce tutte le pubblicazioni disponibili presso un canale
    /**
     * Aggiunge la disponibilita' di una pubblicazione resso un canale di distribuzione in una specifica modalita' di fruizione
     *
     * @param pubblicazione il codice della pubblicazione
     * @param canale il codice del canale
     * @param modalita la modalita' di fruizione
     * @return vero se l'inserimento e' andato a buon fine, falso altrimenti
     */
    public boolean aggiungiDisponibilita (String pubblicazione, int canale, String modalita) {
        String query = "INSERT INTO disponibilitap(isbn, canale, modalitafruizione) VALUES (?, ?, ?)";

        try {
            try(PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, pubblicazione);
                preparedStatement.setInt(2,canale);
                preparedStatement.setString(3, modalita);

                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Inserisce una pubblicazione all'interno del DB
     *
     * @param p la pubblicazione da inserire
     * @return vvero se l'inserimento e' andato a buon fine, falso altrimenti
     */
    public boolean inserisciPubblicazione(Pubblicazione p) {
        String query = "INSERT INTO pubblicazione(isbn, titolo, editore, annopubblicazione, modalitafruizione, conferenza, rivista, autore) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, p.getISBN());
            preparedStatement.setString(2, p.getTitolo());
            preparedStatement.setString(3, p.getEditore());
            preparedStatement.setInt(4, p.getAnnoPubblicazione());

            String modalitaFruizioneString = String.join(", ", p.getModalitaFruizione());
            preparedStatement.setString(5, modalitaFruizioneString);

            // Verifica se è stata specificata una conferenza o una rivista
            if (p.getConferenza() != null) {
                preparedStatement.setInt(6, p.getConferenza().getCodConferenza());
                preparedStatement.setNull(7, java.sql.Types.VARCHAR); // Imposta rivista a NULL
            } else {
                // Se la conferenza è nulla, la rivista non può essere nulla
                if (p.getRivista() == null) {
                    throw new IllegalArgumentException("Rivista non specificata per una pubblicazione senza conferenza.");
                }
                preparedStatement.setNull(6, java.sql.Types.INTEGER); // Imposta conferenza a NULL
                preparedStatement.setString(7, p.getRivista().getDoi());
            }

            String autoriString = String.join(", ", p.getAutori());
            preparedStatement.setString(8, autoriString);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



    /**
     * Trasforma una stringa di modalita' di fruizione separate da ',' in un elenco
     *
     * @param modalitaFruizione le modalita' di fruizione
     * @return l'elenco di modalita'
     */
    private Set<String> recuperaModalitaFruizioneDaDatabase(String modalitaFruizione) {
        return new HashSet<>(Arrays.asList(modalitaFruizione.split("\\s*,\\s*")));
    }
    /**
     * Trasforma una stringa di autori separati da virgola, in un elenco di autori.
     *
     * @param autori la stringa di autori
     * @return un elenco di autori
     */
    private Set<String> recuperaAutoriDaDatabase(String autori) {
        return new HashSet<>(Arrays.asList(autori.split("\\s*,\\s*")));
    }
}
