package implementazionePostgresDAO;

        import ConnessionDatabase.ConnessioneDatabase;
        import DAO.RivistaDAO;
        import model.Rivista;

        import java.sql.Connection;
        import java.sql.PreparedStatement;
        import java.sql.ResultSet;
        import java.sql.SQLException;
        import java.util.ArrayList;
        import java.util.List;

/**
 * La classe RivistaDAOImpl che implementa la classe RivistaDAO
 */
public class RivistaDAOImpl implements RivistaDAO {
    private Connection connection;

    /**
     * Costruttore della classe che ottiene un'istanza della connessione.
     */
    public RivistaDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Recupera tutte le informazioni di una rivista, cercandola tramite il suo codice
     *
     * @param doi il codice identificativo della rivista
     * @return un riferimento ad un oggetto Rivista
     */
    public Rivista recuperaRivistaDaDatabase(String doi) {
        Rivista rivista = null;

        try {
            String query = "SELECT * FROM rivista WHERE doi = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, doi);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Costruisci l'oggetto Rivista
                        rivista = new Rivista(
                                resultSet.getString("doi"),
                                resultSet.getString("nome"),
                                resultSet.getString("argomento"),
                                resultSet.getInt("annopubblicazione"),
                                resultSet.getString("responsabile")

                        );
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rivista;
    }


    /**
     * Ricerca tutte e riviste presenti nel DB
     *
     * @return una lista di codici di riviste
     */
    public List<String> getElencoRiviste () {
        List<String> riviste = new ArrayList<>();

        try {
            String query = "SELECT doi FROM rivista ";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Costruisci l'oggetto Rivista

                        String rivista = resultSet.getString("doi");
                        riviste.add(rivista);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return riviste;


    }
}
