package implementazionePostgresDAO;

import ConnessionDatabase.ConnessioneDatabase;
import DAO.SerieDAO;
import model.Serie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * La classe SerieDAOImpl che istanzia l'interfaccia SerieDAO.
 */
public class SerieDAOImpl implements SerieDAO {

    private Connection connection;

    /**
     * Costruttore della classe che ottiene un'istanza della connessione.
     */
    public SerieDAOImpl() {
        try {
            this.connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Istanzia un oggetto Serie, prendendo tutte le informazioni da un resultSet
     *
     * @param resultSet il resultSet
     * @return un riferimento ad un oggetto Serie
     */
    private Serie costruisciSerieDaResultSet ( ResultSet resultSet) throws SQLException{

        return new Serie(  resultSet.getInt("codserie"), resultSet.getString("nome"));

    }


    /**
     * Cerca tutte le serie presenti nel database
     *
     * @return un elenco contente il nome di tutte le serie
     */
    public List<String> getElencoSerie() {
        List<String> elencoSerie = new ArrayList<>();

        try {
            String query = "SELECT DISTINCT s.nome FROM serie s JOIN libro l ON s.codserie = l.serie";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String serie = resultSet.getString("nome");
                    elencoSerie.add(serie);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elencoSerie;
    }

    /**
     *Cerca tutte le serie presenti nel database
     *
     * @return una lista di interi contenente i codici di tutte le serie
     */
    public List<Integer> getElencoSerieCod() {
        List<Integer> elencoSerie = new ArrayList<>();

        try {
            String query = "SELECT codserie FROM serie";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    Integer n = resultSet.getInt("codserie");
                    elencoSerie.add(n);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elencoSerie;
    }
    /**
     * Cerca una determinata serie mediante il suo codice identificativo
     *
     * @param codSerie il codice della serie
     * @return un riferimento ad un oggetto Serie
     */
    public Serie cercaSerieCod(int codSerie) {
        Serie serie = null;

        try {
            String query = "SELECT * FROM serie WHERE codserie = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1,  codSerie );

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        serie = costruisciSerieDaResultSet(resultSet);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return serie;
    }
    /**
     *Effettua una ricerca sulle serie, filtrandola secondo il valore di uno specifico campo
     *
     * @param attributo il campo
     * @param searchString il valore del campo
     * @return
     */
    public List<Serie> cercaSerie(String attributo, String searchString) {
        List<Serie> risultati = new ArrayList<>();

        try {
            String query = "SELECT * FROM serie WHERE " + attributo+ " LIKE ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, "%" + searchString + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Serie serie = costruisciSerieDaResultSet(resultSet);

                        risultati.add(serie);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return risultati;
    }




}
