package implementazionePostgresDAO;


import ConnessionDatabase.ConnessioneDatabase;
import DAO.UtenteDAO;
import model.Serie;
import model.Utente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * La classe UtenteDAOImpl che istanzia la classe UtenteDAO.
 */
public class UtenteDAOImpl implements UtenteDAO {

    private Connection connection;

    /**
     * COstruttor della classe che ottiene un istanza della connessione.
     */
    public UtenteDAOImpl() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    /**
     * Ricerca un utente all'interno del DB mediante le su credenziali
     *
     * @param matricola la matricola dell'utente
     * @param password la password
     * @return vero se l'utente esiste, falso altrimenti
     */

    public boolean effettuaLogin(int matricola, String password) {
        try {
            String query = "SELECT * FROM utente WHERE idutente = ? AND pwd = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, matricola); // Usa setInt invece di setString per un identificatore numerico
                preparedStatement.setString(2, password);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next(); // Restituisce true se l'utente è presente nel database
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }
    }
    /**
     * Effettua l'inserimento di un nuovo utente all'interno del DB
     *
     * @param matricola la matricola dell'utente
     * @param password la password
     * @param nome il nome
     * @param cognome il cognome
     * @param username l'username
     * @return vero se l'inserimento e' avvenuto correttamente, falso altrimenti
     */
    public boolean effettuaRegistrazione(int matricola, String password, String nome, String cognome, String username) {
        try {

            String query = "INSERT INTO utente (idutente, pwd, nome, cognome, username) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, matricola);
                preparedStatement.setString(2, password);
                preparedStatement.setString(3, nome);
                preparedStatement.setString(4, cognome);
                preparedStatement.setString(5, username);

                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;  // Restituisce true se almeno una riga è stata inserita
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }
    }

    /**
     * Ricerca un utente mediante la sua matricola.
     *
     * @param matricola la matricola
     * @return vero se l'utente è stato trovato, falso altrimenti
     */
    public boolean utenteEsiste(int matricola) {
        try {
            String query = "SELECT 1 FROM utente WHERE idutente = ? ";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, matricola);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next(); // Restituisce true se l'utente esiste
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Gestione dell'eccezione, potresti voler loggare l'errore o altrimenti gestirlo
        }
    }

    /**
     * Verifica se un determinato username e' utilizzato da un utente.
     *
     * @param username l'username
     * @return vero se e' stato trovato un utente con quell'username, falso altrimenti
     */
    public boolean usernameEsiste (String username) {
        try {
            String query = "SELECT 1 FROM utente WHERE username = ? ";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}