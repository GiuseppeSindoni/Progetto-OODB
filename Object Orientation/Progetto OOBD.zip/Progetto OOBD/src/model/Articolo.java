package model;

import java.security.interfaces.DSAParams;
import java.util.*;

/**
 * La classe Articolo.
 */
abstract class Articolo {
    /**
     * Rappresenta il Codice identificativo dell articolo
     */
    private String ISBN;
    /**
     * Rappresenta il titolo dell'articolo
     */
    private String titolo;
    /**
     * Rappresenta l' anno in cui l'articolo e' stato pubblicato
     */
    private int annoPubblicazione;

    /**
     * Rappresenta l'editore che ha pubblicato l'articolo
     */
    private String editore;

    /**
     * Rappresenta le modalita' di fruizione per cui quell'articolo esiste
     */
    private Set<String> modalitaFruizione;

    /**
     * Rappresenta l'insieme di autori che hanno contribuito alla stesura dell'articolo
     */
    private Set<String> autori;

    /**
     * Rappresenta le disponibilita' dell' articolo presso i spceicifici canali di distribuzione in specifiche modalita' di fruizione
     */
    private Map<CanaleDistribuzione, Set<String>> disponibilita = new HashMap<>();


    /**
     * Costruttore della classe Articolo
     *
     * @param ISBN             l' ISBN dell'articolo
     * @param titolo            il titolo
     * @param editore           l' editore che ha pubblicato l'articolo
     * @param annoPubblicazione l' anno di pubblicazione dell'articolo
     * @param autori            gli autori dell'articolo
     */
    public Articolo(String ISBN, String titolo, String editore, int annoPubblicazione, Set<String> autori) {
        this.ISBN = ISBN;
        this.titolo = titolo;
        this.editore = editore;
        this.modalitaFruizione = new HashSet<>();
        this.autori = autori; // inizializzato il set degli autori
        this.annoPubblicazione = annoPubblicazione;
    }

    /**
     * Gets isbn.
     *
     * @return the isbn
     */
    public String getISBN() {
        return ISBN;
    }

    /**
     * Gets titolo.
     *
     * @return the titolo
     */
    public String getTitolo() {
        return titolo;
    }

    /**
     * Gets anno pubblicazione.
     *
     * @return the anno pubblicazione
     */
    public int getAnnoPubblicazione() {
        return annoPubblicazione;
    }

    /**
     * Sets anno pubblicazione.
     *
     * @param annoPubblicazione the anno pubblicazione
     */
    public void setAnnoPubblicazione(int annoPubblicazione) {
        this.annoPubblicazione = annoPubblicazione;
    }

    /**
     * Gets editore.
     *
     * @return the editore
     */
    public String getEditore() {
        return editore;
    }

    /**
     * Sets editore.
     *
     * @param editore the editore
     */
    public void setEditore(String editore) {
        this.editore = editore;
    }

    /**
     * Aggiungi modalita fruizione.
     *
     * @param modalita the modalita
     */
    public void aggiungiModalitaFruizione(String modalita) {
        modalitaFruizione.add(modalita);
    }

    /**
     * Sets modalita fruizione.
     *
     * @param modalita the modalita
     */
    public void setModalitaFruizione( Set<String> modalita) {this.modalitaFruizione = modalita;}

    /**
     * Gets modalita fruizione.
     *
     * @return the modalita fruizione
     */
    public Set<String> getModalitaFruizione() {
        return modalitaFruizione;
    }

    /**
     * Aggiungi autore.
     *
     * @param autore the autore
     */
    public void aggiungiAutore(String autore) {
        autori.add(autore); // corretto l'uso del metodo add
    }

    /**
     * Gets autori.
     *
     * @return the autori
     */
    public Set<String> getAutori() {
        return autori; // corretto il nome del metodo
    }


    /**
     * Aggiungi disponibilita dell'articolo presso uno specifico canale in una o piu' modalita di fruizione.
     *
     * @param c Il canale di distribuzione
     * @param l La\le modalita' per cui sara' disponbile quell'articolo presso quel canale
     */
    public void aggiungiDisponibilita ( CanaleDistribuzione c, Set<String> l){
        disponibilita.put(c,l);
    }

    /**
     * Rimuovi disponibilita dell'articolo presso uno specifico canale.
     *
     * @param c Il canale di distribuzione
     */
    public void rimuoviDisponibilita(CanaleDistribuzione c) {
        disponibilita.remove(c);
    }

    /**
     * Setta l'insieme di tutte le disponibilita' dell'articolo.
     *
     * @param disp l'insieme di tutte le disponibilita' dell'articolo
     */
    public void setDisponibilita(HashMap<CanaleDistribuzione, Set<String >> disp) {
        disponibilita = disp;
    }

    /**
     * Restituisce tutte le disponibilita'.
     *
     * @return tutte le disponibilita'
     */
    public  Map<CanaleDistribuzione, Set<String >> getDisponibilita() {
        return disponibilita;
    }
}