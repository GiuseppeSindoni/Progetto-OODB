    package model;

    import java.time.LocalTime;
    import java.util.List;
    import java.util.Map;
    import java.util.Set;

    /**
     * La classe CanaleDistribuzione.

     */
    public class CanaleDistribuzione {

        private int codCanale;
        private String nome, tipoCanale, url, indirizzo, numeroTelefono;
        private LocalTime orarioApertura;
        private LocalTime orarioChiusura;

        /**
         * Rappresenta le disponibilita' di tutti gli articoli presso se stesso.
         */
        Map<Articolo, Set<String>> disponibilita;


        /**
         * Costruttore della classe CanaleDistribuzione per instanziare Siti Online
         *
         * @param codCanale  il codice del canale
         * @param nome       il nome del canale
         * @param tipoCanale il tipo del canale
         * @param url        l'url del sito
         */
        public CanaleDistribuzione (int codCanale, String nome, String tipoCanale, String url) {

            this.codCanale = codCanale;
            this.nome = nome;
            this.tipoCanale= tipoCanale;
            this.url = url;

        }

        /**
         * Costruttore della classe CanaleDistribuzione per instanziare Librerie
         *
         * @param codCanale      il codice del canale
         * @param nome           il nome
         * @param tipoCanale     il tipo del canale
         * @param indirizzo      l'indirizzo della libreria
         * @param numeroTelefono il numero di telefono
         * @param orarioA        orario di apertura
         * @param orarioC        orario di chiusura
         */
        public CanaleDistribuzione (int codCanale, String nome, String tipoCanale, String indirizzo, String numeroTelefono, LocalTime orarioA, LocalTime orarioC) {

            this.codCanale = codCanale;
            this.nome = nome;
            this.tipoCanale= tipoCanale;
            this.indirizzo = indirizzo;
            this.numeroTelefono = numeroTelefono;
            this.orarioApertura = orarioA;
            this.orarioChiusura = orarioC;

        }


        /**
         * Gets cod canale.
         *
         * @return the cod canale
         */
        public int getCodCanale() {
            return codCanale;
        }

        /**
         * Sets cod canale.
         *
         * @param codCanale the cod canale
         */
        public void setCodCanale(int codCanale) {
            this.codCanale = codCanale;
        }

        /**
         * Gets nome.
         *
         * @return the nome
         */
        public String getNome() {
            return nome;
        }

        /**
         * Sets nome.
         *
         * @param nome the nome
         */
        public void setNome(String nome) {
            this.nome = nome;
        }

        /**
         * Gets tipocanale.
         *
         * @return the tipocanale
         */
        public String getTipocanale() {
            return tipoCanale;
        }

        /**
         * Sets tipocanale.
         *
         * @param tipocanale the tipocanale
         */
        public void setTipocanale(String tipocanale) {
            this.tipoCanale = tipocanale;
        }

        /**
         * Gets url.
         *
         * @return the url
         */
        public String getUrl() {
            return url;
        }

        /**
         * Sets url.
         *
         * @param url the url
         */
        public void setUrl(String url) {
            this.url = url;
        }

        /**
         * Gets indirizzo.
         *
         * @return the indirizzo
         */
        public String getIndirizzo() {
            return indirizzo;
        }

        /**
         * Sets indirizzo.
         *
         * @param indirizzo the indirizzo
         */
        public void setIndirizzo(String indirizzo) {
            this.indirizzo = indirizzo;
        }

        /**
         * Gets numero telefono.
         *
         * @return the numero telefono
         */
        public String getNumeroTelefono() {
            return numeroTelefono;
        }

        /**
         * Sets numero telefono.
         *
         * @param numerotelefono the numerotelefono
         */
        public void setNumeroTelefono(String numerotelefono) {
            this.numeroTelefono = numerotelefono;
        }

        /**
         * Gets orario apertura.
         *
         * @return the orario apertura
         */
        public LocalTime getOrarioApertura() {
            return orarioApertura;
        }

        /**
         * Sets orario apertura.
         *
         * @param orarioApertura the orario apertura
         */
        public void setOrarioApertura(LocalTime orarioApertura) {
            this.orarioApertura = orarioApertura;
        }

        /**
         * Gets orario chiusura.
         *
         * @return the orario chiusura
         */
        public LocalTime getOrarioChiusura() {
            return orarioChiusura;
        }

        /**
         * Sets orario chiusura.
         *
         * @param orarioChiusura the orario chiusura
         */
        public void setOrarioChiusura(LocalTime orarioChiusura) {
            this.orarioChiusura = orarioChiusura;
        }


        /**
         * Setta tutte le disponibilita' presso il canale.
         *
         * @param disponibilita gli articoli disponibili presso il canale nelle rispettive modalita' di fruizione
         */
        public void setDisponibilita(Map<Articolo, Set<String>> disponibilita) {
            this.disponibilita = disponibilita;
        }

        /**
         * Restituisce le disponibilita' di tutti i libri presenti sul canale.
         *
         * @return gli articoli disponibili presso il canale nelle rispettive modalita' di fruizione
         */
        public Map<Articolo, Set<String>> getDisponibilita() {
            return disponibilita;
        }

        /**
         * Aggiungi disponabilita di un articolo presso il canale in una o piu' modalita' di fruizione.
         *
         * @param a   L'articolo da "aggiungere" sul canale
         * @param mod la\le modalita di fruizione per cui l'articolo sara' disponibile sul canale
         */
        public void aggiungiDisponabilita( Articolo a, Set<String> mod) {
             disponibilita.put(a, mod);
        }

        /**
         * Rimuovi tutte le disponabilita' di un articolo presso il canale.
         *
         * @param a   L'articolo da "rimuovere" sul canale*/
        public void rimuoviDisponibilita (Articolo a) { disponibilita.remove(a);}
    }
