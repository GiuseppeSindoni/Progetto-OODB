package model;

import java.util.List;
import java.util.ArrayList;

/**
 * Classe Collana.
 */
public class Collana {
    private int codcollana;
    private String nome;
    private String editore;

    private String criterio;

    /**
     * I libri che appartengono alla collana.
     */
    private List<Libro>libri = new ArrayList<>();

    /**
     * Costruttore della classe collana
     *
     * @param id       il codice della collana
     * @param nome     il nome
     * @param editore  l' editore
     * @param criterio il criterio che accoumuna tutti i libri che fanno parte della collana
     */
// Costruttore
    public Collana(int id, String nome, String editore, String criterio) {
        this.codcollana = id;
        this.nome = nome;
        this.editore = editore;
        this.criterio = criterio;
    }

    /**
     * Gets codcollana.
     *
     * @return the codcollana
     */
// Metodi getter
    public int getCodcollana() {
        return codcollana;
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Gets editore.
     *
     * @return the editore
     */
    public String getEditore() {
        return editore;
    }

    /**
     * Sets codcollana.
     *
     * @param id the id
     */
// Metodi setter
    public void setCodcollana(int id) {
        this.codcollana = id;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Sets editore.
     *
     * @param editore the editore
     */
    public void setEditore(String editore) {
        this.editore = editore;
    }

    /**
     * Aggiungi libro.
     *
     * @param libro the libro
     */
    public void aggiungiLibro(Libro libro) {
        libri.add(libro);
    }

    /**
     * Rimuovi libro.
     *
     * @param libro the libro
     */
    public void rimuoviLibro(Libro libro) {
        libri.remove(libro);
    }

    /**
     * Gets libri.
     *
     * @return the libri
     */
// Metodo per ottenere la lista dei libri nella collana
    public List<Libro> getLibri() {
        return libri;
    }

    /**
     * Gets criterio.
     *
     * @return the criterio
     */
    public String getCriterio() {
        return criterio;
    }

    /**
     * Sets criterio.
     *
     * @param criterio the criterio
     */
    public void setCriterio(String criterio) { this.criterio = criterio;}
}