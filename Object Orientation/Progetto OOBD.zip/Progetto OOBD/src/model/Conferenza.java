package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Classe Conferenza.
 */
public class Conferenza {

    private String strutturaOrganizzatrice;

    private int codConferenza;

    private String luogo;

    private Date dataInizio;

    private Date dataFine;

    private String responsabile;

    private String nome;

    private List<Pubblicazione> pubblicazioni = new ArrayList<>();

    /**
     * Costruttore della classe Conferenza.
     *
     * @param codconferenza           il codice della conferenza
     * @param nome                    il nome della conferenza
     * @param dataInizio              la data di inizio
     * @param dataFine                la data di fine
     * @param luogo                   il luogo dove e' avvenuta la conferenza
     * @param responsabile            il responsabile della conferenza
     * @param strutturaorganizzatrice la struttura organizzatrice
     */
// Costruttore
    public Conferenza(int codconferenza, String nome,java.sql.Date dataInizio, java.sql.Date dataFine, String luogo, String responsabile, String strutturaorganizzatrice) {
        this.codConferenza = codconferenza;
        this.dataInizio = new Date(dataInizio.getTime());
        this.dataFine = new Date(dataFine.getTime());
        this.luogo = luogo;
        this.responsabile = responsabile;
        this.strutturaOrganizzatrice = strutturaorganizzatrice;
        this.nome = nome;
    }

    /**
     * Gets cod conferenza.
     *
     * @return the cod conferenza
     */
// Metodi getter
    public int getCodConferenza() {
        return codConferenza;
    }

    /**
     * Gets luogo.
     *
     * @return the luogo
     */
    public String getLuogo() {
        return luogo;
    }

    /**
     * Gets data inizio.
     *
     * @return the data inizio
     */
    public Date getDataInizio() {
        return dataInizio;
    }

    /**
     * Gets data fine.
     *
     * @return the data fine
     */
    public Date getDataFine() {
        return dataFine;
    }

    /**
     * Gets responsabile.
     *
     * @return the responsabile
     */
    public String getResponsabile() {
        return responsabile;
    }

    /**
     * Gets pubblicazioni.
     *
     * @return the pubblicazioni
     */
    public List<Pubblicazione> getPubblicazioni () {return pubblicazioni;}

    // Metodi setter

    /**
     * Sets pubblicazioni.
     *
     * @param pubb the pubb
     */
    public void setPubblicazioni(List<Pubblicazione> pubb) {this.pubblicazioni = pubb;}

    /**
     * Sets cod conferenza.
     *
     * @param id the id
     */
    public void setCodConferenza(int id) {
        this.codConferenza = id;
    }

    /**
     * Sets luogo.
     *
     * @param luogo the luogo
     */
    public void setLuogo(String luogo) {
        this.luogo = luogo;
    }

    /**
     * Sets data inizio.
     *
     * @param dataInizio the data inizio
     */
    public void setDataInizio(Date dataInizio) {
        this.dataInizio = dataInizio;
    }

    /**
     * Sets data fine.
     *
     * @param dataFine the data fine
     */
    public void setDataFine(Date dataFine) {
        this.dataFine = dataFine;
    }

    /**
     * Sets responsabile.
     *
     * @param responsabile the responsabile
     */
    public void setResponsabile(String responsabile) {
        this.responsabile = responsabile;
    }

    /**
     * Aggiungi pubblicazione.
     *
     * @param pubblicazione the pubblicazione
     */
    public void aggiungiPubblicazione (Pubblicazione pubblicazione) {
        this.pubblicazioni.add(pubblicazione);
    }


    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String  getNome () {return this.nome;}
}
