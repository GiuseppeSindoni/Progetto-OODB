package model;

import model.Serie;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * La classe Libro.
 */
public class Libro extends Articolo{
    /**
     * Data uscita del libro.
     */
    private Date dataUscita;
    /**
     * La sala dove e' stato presentato il libro.
     */
    private String sala;
    /**
     * Il tipo del libro (Didattico, Romanzo).
     */
    private String tipo;
    /**
     * Le Collane a cui fa parte il libro.
     */
    private List<Collana> collane = new ArrayList<>();

    /**
     * L'eventuale serie a cui appartiene il libro (solo se dio tipo romanzo).
     */
    private Serie serie;


    /**
     * Costruttore della classe libro, nel caso di un libro di tipo romanzo chew appartiene ad una serie.
     *
     * @param ISBN              the isbn
     * @param titolo            the titolo
     * @param editore           the editore
     * @param data              the data
     * @param sala              the sala
     * @param tipo              the tipo
     * @param annoPubblicazione the anno pubblicazione
     * @param autori            the autori
     * @param serie             the serie
     */
    public Libro(String ISBN, String titolo, String editore, Date data, String sala, String tipo, int annoPubblicazione, Set<String> autori, Serie serie) {
        super(ISBN, titolo, editore, annoPubblicazione, autori);
        this.dataUscita = data;
        this.sala = sala;
        this.tipo = tipo;
        this.serie = serie;
    }

    /**
     * Costruttore della classe libro per un libro che non appartiene ad alcuna serie.
     *
     * @param ISBN              the isbn
     * @param titolo            the titolo
     * @param editore           the editore
     * @param data              the data
     * @param sala              the sala
     * @param tipo              the tipo
     * @param annoPubblicazione the anno pubblicazione
     * @param autori            the autori
     */
    public Libro(String ISBN, String titolo, String editore, Date data, String sala, String tipo, int annoPubblicazione, Set<String> autori) {
        super(ISBN, titolo, editore, annoPubblicazione, autori);
        this.dataUscita = data;
        this.sala = sala;
        this.tipo = tipo;
        this.serie = null;
    }

    /**
     * Gets data uscita.
     *
     * @return the data uscita
     */
    public Date getDataUscita() {
        return dataUscita;
    }

    /**
     * Sets data uscita.
     *
     * @param data the data
     */
    public void setDataUscita(Date data) {
        this.dataUscita = data;
    }

    /**
     * Gets sala.
     *
     * @return the sala
     */
    public String getSala() {
        return sala;
    }

    /**
     * Sets sala.
     *
     * @param sala the sala
     */
    public void setSala(String sala) {
        this.sala = sala;
    }

    /**
     * Gets tipo.
     *
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets tipo.
     *
     * @param tipo the tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    /**
     * Aggiungi una collana, alla lista delle collane a cui appartiene il libro.
     *
     * @param collana la collana a cui il libro apparterra'
     */
    public void aggiungiCollana(Collana collana) {
        collane.add(collana);
    }

    /**
     * Rimuovi una collana dalla lista delle collaner a cui appartiene il libro.
     *
     * @param collana la collana che si vuole rimuovere dall'elenco
     */
    public void rimuoviCollana(Collana collana) {
        collane.remove(collana);
    }


    /**
     * Restituisce le collane a cui appartiene il libro.
     *
     * @return la lista della collane
     */
    public List<Collana> getCollane() {
        return collane;
    }

    /**
     * Setta la serie a cui appartiene il libro.
     *
     * @param serie la serie a cui il libro apparterra'
     */
    public void setSerie(Serie serie) {
        if(tipo.equals("Romanzo"))
            this.serie = serie;
    }

    /**
     * Restituisce la serie a cui appartiene il libro
     *
     * @return la serie del libro
     */
    public Serie getSerie () {
        return this.serie;
    }


}