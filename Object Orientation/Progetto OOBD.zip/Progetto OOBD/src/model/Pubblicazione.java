package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Classe Pubblicazione.
 */
public class Pubblicazione extends Articolo {

    private Conferenza conferenza;
    private Rivista rivista;


    /**
     * Costruttore della classe Pubblicazione, per una pubblicazione che e' stat pubblicata tramite una conferenza
     *
     * @param ISBN              il codice identificativo della pubblicazione
     * @param titolo            il titolo della pubblicazione
     * @param editore           l'editore che ha pubblicato la pubblicazione
     * @param annoPubblicazione l'anno di pubblicazione
     * @param autori            il\gli autori
     * @param conferenza        la conferenza dove la pubblicazione e' stata pubblicata
     */
// Costruttore per Conferenza
    public Pubblicazione(String ISBN, String titolo, String editore, int annoPubblicazione, Set<String> autori, Conferenza conferenza) {
        super(ISBN, titolo, editore, annoPubblicazione, autori);
        this.conferenza = conferenza;
        this.rivista = null;

    }

    /**
     * Costruttore della classe Pubblicazione, per una pubblicazione che e' stat pubblicata tramite una rivista

     *
     * @param ISBN              il codice identificativo della pubblicazione
     * @param titolo            il titolo della pubblicazione
     * @param editore           l'editore che ha pubblicato la pubblicazione
     * @param annoPubblicazione l'anno di pubblicazione
     * @param autori            il\gli autori
     * @param rivista        la rivista dove la pubblicazione e' stata pubblicata
     */
// Costruttore per Rivista
    public Pubblicazione(String ISBN, String titolo, String editore, int annoPubblicazione, Set<String> autori, Rivista rivista) {
        super(ISBN, titolo, editore, annoPubblicazione, autori);
        this.rivista = rivista;
        this.conferenza = null;
    }


    /**
     * Gets conferenza.
     *
     * @return the conferenza
     */
    public Conferenza getConferenza() {
        return conferenza;
    }

    /**
     * Sets conferenza.
     *
     * @param conferenza the conferenza
     */
    public void setConferenza(Conferenza conferenza) {
        this.conferenza = conferenza;
    }

    /**
     * Gets rivista.
     *
     * @return the rivista
     */
    public Rivista getRivista() {
        return rivista;
    }

    /**
     * Sets rivista.
     *
     * @param rivista the rivista
     */
    public void setRivista(Rivista rivista) {
        this.rivista = rivista;
    }




}
