package model;

import model.Pubblicazione;

import java.util.List;
import java.util.ArrayList;

/**
 * La classe Rivista.
 */
public class Rivista {
    /**
     * Il codice identificativo della rivista.
     */
    private String doi;
    /**
     * Il Nome.
     */
    private String nome;
    /**
     * L'argomento principale.
     */
    private String argomento;

    /**
     * L'anno di pubblicazione.
     */
    private int annoPubblicazione;
    /**
     * Il responsabile della rivista.
     */
    private String responsabile;

    /**
     * La lista di Pubblicazioni, presentate tramite la rivista.
     */
    private List<Pubblicazione> pubblicazioni = new ArrayList<>();

    /**
     * Costruttore della classe Rivista.
     *
     * @param doi               il doi
     * @param nome              il nome
     * @param argomento         l'argomento
     * @param annopubblicazione l'anno di pubblicazione
     * @param responsabile      il responsabile
     */
// Costruttore
    public Rivista(String doi, String nome, String argomento,int annopubblicazione, String responsabile) {
        this.doi = doi;
        this.nome = nome;
        this.argomento = argomento;
        this.annoPubblicazione = annopubblicazione;
        this.responsabile = responsabile;
    }

    /**
     * Gets doi.
     *
     * @return the doi
     */
// Metodi getter
    public String getDoi() {
        return doi;
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Gets argomento.
     *
     * @return the argomento
     */
    public String getArgomento() {
        return argomento;
    }

    /**
     * Gets responsabile.
     *
     * @return the responsabile
     */
    public String getResponsabile() {
        return responsabile;
    }

    /**
     * Gets pubblicazioni.
     *
     * @return the pubblicazioni
     */
    public List<Pubblicazione> getPubblicazioni() { return pubblicazioni;}

    /**
     * Sets pubblicazioni.
     *
     * @param pubb the pubb
     */
    public void setPubblicazioni (List<Pubblicazione> pubb) {
        this.pubblicazioni = pubb;
    }

    /**
     * Sets doi.
     *
     * @param id the id
     */
// Metodi setter
    public void setDoi(String id) {
        this.doi = id;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Sets argomento.
     *
     * @param argomento the argomento
     */
    public void setArgomento(String argomento) {
        this.argomento = argomento;
    }

    /**
     * Sets responsabile.
     *
     * @param responsabile the responsabile
     */
    public void setResponsabile(String responsabile) {
        this.responsabile = responsabile;
    }


    /**
     * Aggiungi una pubblicazione tra quelle presentate tramite la rivista.
     *
     * @param pubblicazione la pubblicazione, presentata tramite la rivista
     */
    public void aggiungiPubblicazione (Pubblicazione pubblicazione) {
        this.pubblicazioni.add(pubblicazione);
    }

    /**
     * Rimuovi una pubblicazione dall' elenco di quelle pubblicate tramite la rivista.
     *
     * @param pubblicazione la pubblicazione da rimuovere
     */
    public void rimuoviPubblicazione (Pubblicazione pubblicazione) { this.pubblicazioni.remove(pubblicazione);}
}
