package model;

import java.util.List;

/**
 * Classe Serie.
 */
public class Serie {
    /**
     * Codice identificativo della serie.
     */
    private int codserie;
    /**
     * Il Nome.
     */
    private String nome;

    /**
     * I Libri appartenenti alla serie.
     */
    private List<Libro> libri;

    /**
     * Costruttore della classe Serie.
     *
     * @param codserie il codice della serie
     * @param nome     il nome
     */
// Costruttore della classe
    public Serie(int codserie, String nome) {
        this.codserie = codserie;
        this.nome = nome;

    }

    /**
     * Aggiungi un libro alla serie.
     *
     * @param libro il libro da aggiungere alla serie
     */
    public void aggiungiLibro (Libro libro) {
        this.libri.add(libro);

    }

    /**
     * Rimuovi un libro dalla serie.
     *
     * @param libro il libro da rimuovere
     */
    public void rimuoviLibro (Libro libro) {
        this.libri.remove(libro);
    }

    /**
     * Ottieni i libri appartenenti alla serie.
     *
     * @return the libri
     */
    public List<Libro> getLibri () { return this.libri;     }

    /**
     * Setta i libri che appartengono alla serie.
     *
     * @param lib la lista di libri che comporranno la serie
     */
    public void setLibri(List<Libro> lib) { libri = lib; }

    /**
     * Gets nome.
     *
     * @return the nome
     */
// Metodo getter per ottenere il valore del nome
    public String getNome() {
        return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
// Metodo setter per impostare il valore del nome
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets cod serie.
     *
     * @return the cod serie
     */
    public int getCodSerie() {
        return codserie;
    }
}
