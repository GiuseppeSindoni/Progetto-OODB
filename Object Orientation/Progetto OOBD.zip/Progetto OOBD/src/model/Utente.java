package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Classs Utente.
 */
public class Utente {
    /**
     * Codice identificativo dell'utente
     */

    private int matricola;
    /**
     * Il Nome dell'utente.
     */
    private String nome, /**
     * Il Cognome.
     */
    cognome, /**
     * La Password.
     */
    password, /**
     * l'Username.
     */
    username;

    /**
     * L'elenco di serie che interessano all'utente.
     */
    private List<Serie> preferiti = new ArrayList<>();

    /**
     * Costruttore della classe Utente.
     *
     * @param matricola la matricola
     * @param nome      il nome
     * @param cognome   il cognome
     * @param username  l'username
     * @param password  il password
     */
// Costruttore della classe
    public Utente(int matricola, String nome, String cognome, String username, String password) {
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        this.password = password;
        this.username = username;
    }

    /**
     * Sets username.
     *
     * @param username the username
     */
    public void setUsername(String username) { this.username = username;}

    /**
     * Gets username.
     *
     * @return the username
     */
    public String getUsername () {return username;}

    /**
     * Gets matricola.
     *
     * @return the matricola
     */

    public int getMatricola() {
        return matricola;
    }

    /**
     * Sets matricola.
     *
     * @param matricola the matricola
     */

    public void setMatricola(int matricola) {
        this.matricola = matricola;
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */

    public String getNome() {
        return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */

    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets cognome.
     *
     * @return the cognome
     */

    public String getCognome() {
        return cognome;
    }

    /**
     * Sets cognome.
     *
     * @param cognome the cognome
     */

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    /**
     * Gets password.
     *
     * @return the password
     */

    public String getPassword() {
        return password;
    }

    /**
     * Sets password.
     *
     * @param password the password
     */

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Ottieni le serie preferite dell'utente.
     *
     * @return le serie preferite dlel'utente
     */

    public List<Serie> getPreferiti() {
        return preferiti;
    }

    /**
     * Setta le serie preferite dell'utente.
     *
     * @param preferiti the preferiti
     */

    public void setPreferiti(List<Serie> preferiti) {
        this.preferiti = preferiti;
    }

    /**
     * Aggiungi una serie all'elenco dei preferiti dell'utente.
     *
     * @param nuovaSerie la serie da aggiungere all'elenco
     */

    public void aggiungiSeriePreferita(Serie nuovaSerie) {
        preferiti.add(nuovaSerie);
    }

    /**
     * Rimuovi una serie dai preferiti.
     *
     * @param serieDaRimuovere la serie da rimuovere dall'elenco
     */

    public void rimuoviSeriePreferita(Serie serieDaRimuovere) {
        preferiti.remove(serieDaRimuovere);
    }
}
